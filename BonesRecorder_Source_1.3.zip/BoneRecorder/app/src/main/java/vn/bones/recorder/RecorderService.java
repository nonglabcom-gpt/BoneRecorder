package vn.bones.recorder;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioPlaybackCaptureConfiguration;
import android.media.AudioRecord;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.FileDescriptor;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.Date;
import java.util.Locale;

/** Screen recorder using MediaCodec + MediaMuxer. Optional app-playback capture uses AudioPlaybackCapture (Android 10+), never MIC. */
public class RecorderService extends Service {
    private static final String CHANNEL = "bones_recording";
    private static final int NOTIFICATION_ID = 41;
    private static final String ACTION_STATE = "vn.bones.recorder.STATE";
    private static final String PREFS = "bones_recorder";
    private static final String KEY_RECORDING = "recording";

    private static final int AUDIO_SAMPLE_RATE = 48000;
    private static final int AUDIO_CHANNELS = 2;
    private static final int AUDIO_BYTES_PER_FRAME = AUDIO_CHANNELS * 2;

    private MediaProjection projection;
    private MediaCodec videoEncoder;
    private MediaCodec audioEncoder;
    private AudioRecord playbackAudioRecord;
    private Surface videoInputSurface;
    private VirtualDisplay virtualDisplay;
    private MediaMuxer muxer;
    private MuxerWriter muxerWriter;
    private ParcelFileDescriptor output;
    private Uri videoUri;

    private Thread videoDrainThread;
    private Thread audioEncodeThread;
    private volatile boolean stopRequested;
    private volatile boolean recording;
    private volatile boolean paused;
    private volatile boolean stopping;
    private volatile long audioResumeGeneration;
    private boolean recordInternalAudio;
    private boolean audioTrackExpected;
    private boolean muxerStarted;
    private int videoTrack = -1;
    private int audioTrack = -1;
    private long audioPresentationTimeUs;

    private WindowManager windowManager;
    private LinearLayout expandedView;
    private TextView expandedTitle;
    private TextView collapsedTitle;
    private Button pauseButton;
    private WindowManager.LayoutParams windowParams;
    private boolean collapsed;

    @Override public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        String action = intent.getAction();
        if ("STOP".equals(action)) {
            stopRecording();
            return START_NOT_STICKY;
        }
        if ("PAUSE_TOGGLE".equals(action)) {
            togglePause();
            return START_NOT_STICKY;
        }

        Notification notification = buildNotification("Đang chuẩn bị quay màn hình");
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }

        try {
            int resultCode = intent.getIntExtra("resultCode", Activity.RESULT_CANCELED);
            Intent projectionData = intent.getParcelableExtra("projectionData");
            recordInternalAudio = intent.getBooleanExtra("recordInternalAudio", false);
            if (recordInternalAudio && Build.VERSION.SDK_INT < 29) {
                recordInternalAudio = false;
                notifyUser("Thiết bị cần Android 10 trở lên để thu âm thanh nội bộ.");
            }
            MediaProjectionManager manager = (MediaProjectionManager)getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            projection = manager.getMediaProjection(resultCode, projectionData);
            if (projection == null) throw new IllegalStateException("Không tạo được phiên quay màn hình.");
            startRecordingPipeline();
        } catch (Exception error) {
            notifyUser("Không thể bắt đầu quay: " + error.getMessage());
            stopRecording();
        }
        return START_NOT_STICKY;
    }

    private void startRecordingPipeline() throws Exception {
        DisplayMetrics metrics = new DisplayMetrics();
        WindowManager wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        wm.getDefaultDisplay().getRealMetrics(metrics);
        int screenWidth = metrics.widthPixels;
        int screenHeight = metrics.heightPixels;
        int densityDpi = metrics.densityDpi;

        float scale = Math.min(1f, 1920f / Math.max(screenWidth, screenHeight));
        int width = Math.max(2, ((int)(screenWidth * scale)) & ~1);
        int height = Math.max(2, ((int)(screenHeight * scale)) & ~1);

        String filename = "BonesRecorder_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".mp4";
        ContentValues values = new ContentValues();
        values.put(MediaStore.Video.Media.DISPLAY_NAME, filename);
        values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
        if (Build.VERSION.SDK_INT >= 29) {
            values.put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/BonesRecorder");
            values.put(MediaStore.Video.Media.IS_PENDING, 1);
        }
        videoUri = getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
        if (videoUri == null) throw new IllegalStateException("Không tạo được tệp video.");
        output = getContentResolver().openFileDescriptor(videoUri, "w");
        if (output == null) throw new IllegalStateException("Không mở được tệp video.");
        FileDescriptor fileDescriptor = output.getFileDescriptor();

        muxer = new MediaMuxer(fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);

        prepareVideoEncoder(width, height);
        if (recordInternalAudio) {
            try {
                preparePlaybackAudioCapture();
                audioTrackExpected = true;
            } catch (Exception audioError) {
                releaseAudioCaptureQuietly();
                recordInternalAudio = false;
                audioTrackExpected = false;
                notifyUser("Không bật được âm thanh nội bộ; video sẽ tiếp tục không có tiếng.");
            }
        }

        projection.registerCallback(new MediaProjection.Callback() {
            @Override public void onStop() {
                if (!stopping) stopRecording();
            }
        }, new Handler(Looper.getMainLooper()));

        muxerWriter = new MuxerWriter(muxer, recordInternalAudio);

        videoEncoder.start();

        virtualDisplay = projection.createVirtualDisplay(
                "BonesRecorder", width, height, densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                videoInputSurface, null, null);
        if (virtualDisplay == null) throw new IllegalStateException("Không tạo được màn hình ảo.");

        if (recordInternalAudio && playbackAudioRecord != null) {
            audioEncoder.start();
            playbackAudioRecord.startRecording();
            if (playbackAudioRecord.getRecordingState() != AudioRecord.RECORDSTATE_RECORDING)
                throw new IllegalStateException("Không bắt đầu được thu âm thanh nội bộ.");
        }

        recording = true;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_RECORDING, true).apply();
        sendState(true);
        showFloatingControls();
        updateNotification("Đang quay • MP4 • " + (recordInternalAudio ? "Âm thanh nội bộ bật" : "Không âm thanh"));

        videoDrainThread = new Thread(this::videoDrainLoop, "BonesVideoDrain");
        videoDrainThread.start();
        if (recordInternalAudio && playbackAudioRecord != null) {
            audioEncodeThread = new Thread(this::audioEncodeLoop, "BonesAudioCapture");
            audioEncodeThread.start();
        }
    }

    private void prepareVideoEncoder(int width, int height) throws Exception {
        MediaFormat format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height);
        format.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
        format.setInteger(MediaFormat.KEY_BIT_RATE, 6_000_000);
        format.setInteger(MediaFormat.KEY_FRAME_RATE, 30);
        format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2);
        videoEncoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
        videoEncoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
        videoInputSurface = videoEncoder.createInputSurface();
    }

    private void preparePlaybackAudioCapture() throws Exception {
        if (Build.VERSION.SDK_INT < 29) throw new UnsupportedOperationException("Audio playback capture cần Android 10 trở lên.");
        AudioPlaybackCaptureConfiguration captureConfiguration = new AudioPlaybackCaptureConfiguration.Builder(projection)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .build();

        AudioFormat playbackFormat = new AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(AUDIO_SAMPLE_RATE)
                .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                .build();
        int minBuffer = AudioRecord.getMinBufferSize(AUDIO_SAMPLE_RATE, AudioFormat.CHANNEL_IN_STEREO,
                AudioFormat.ENCODING_PCM_16BIT);
        if (minBuffer <= 0) minBuffer = AUDIO_SAMPLE_RATE * AUDIO_BYTES_PER_FRAME / 4;
        playbackAudioRecord = new AudioRecord.Builder()
                .setAudioFormat(playbackFormat)
                .setBufferSizeInBytes(Math.max(minBuffer * 2, 16384))
                .setAudioPlaybackCaptureConfig(captureConfiguration)
                .build();
        if (playbackAudioRecord.getState() != AudioRecord.STATE_INITIALIZED)
            throw new IllegalStateException("AudioRecord không khởi tạo được.");

        MediaFormat audioFormat = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC,
                AUDIO_SAMPLE_RATE, AUDIO_CHANNELS);
        audioFormat.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC);
        audioFormat.setInteger(MediaFormat.KEY_BIT_RATE, 128000);
        audioFormat.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384);
        audioEncoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC);
        audioEncoder.configure(audioFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
    }

    private void videoDrainLoop() {
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        boolean endOfStream = false;
        while (!endOfStream) {
            int outputIndex;
            try { outputIndex = videoEncoder.dequeueOutputBuffer(info, 10000); }
            catch (Exception error) { break; }
            if (outputIndex == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (stopRequested) continue;
                continue;
            } else if (outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                try { videoTrack = muxerWriter.addTrack(videoEncoder.getOutputFormat(), true); }
                catch (Exception error) { notifyUser("Không thể tạo track video: " + error.getMessage()); }
            } else if (outputIndex >= 0) {
                ByteBuffer encoded = videoEncoder.getOutputBuffer(outputIndex);
                if (encoded != null && info.size > 0 && videoTrack >= 0
                        && (info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                    try { muxerWriter.writeSample(videoTrack, encoded, info); }
                    catch (Exception error) { notifyUser("Lỗi ghi video: " + error.getMessage()); }
                }
                endOfStream = (info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0;
                videoEncoder.releaseOutputBuffer(outputIndex, false);
            }
        }
    }

    private void audioEncodeLoop() {
        byte[] pcm = new byte[16384];
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        boolean audioEos = false;
        long presentationTimeUs = System.nanoTime() / 1000L;
        long observedResumeGeneration = audioResumeGeneration;

        while (!stopRequested) {
            if (paused) {
                try { Thread.sleep(15); } catch (InterruptedException ignored) {}
                continue;
            }
            if (observedResumeGeneration != audioResumeGeneration) {
                observedResumeGeneration = audioResumeGeneration;
                presentationTimeUs = System.nanoTime() / 1000L;
            }
            int read;
            try { read = playbackAudioRecord.read(pcm, 0, pcm.length); }
            catch (Exception error) { read = -1; }
            if (read > 0) {
                int inputIndex = audioEncoder.dequeueInputBuffer(10000);
                if (inputIndex >= 0) {
                    ByteBuffer input = audioEncoder.getInputBuffer(inputIndex);
                    if (input != null) {
                        input.clear();
                        int bytes = Math.min(read, input.remaining());
                        bytes -= bytes % AUDIO_BYTES_PER_FRAME;
                        input.put(pcm, 0, bytes);
                        long frames = bytes / AUDIO_BYTES_PER_FRAME;
                        audioEncoder.queueInputBuffer(inputIndex, 0, bytes, presentationTimeUs, 0);
                        presentationTimeUs += frames * 1_000_000L / AUDIO_SAMPLE_RATE;
                    } else {
                        audioEncoder.queueInputBuffer(inputIndex, 0, 0, presentationTimeUs, 0);
                    }
                }
            } else {
                try { Thread.sleep(10); } catch (InterruptedException ignored) {}
            }
            drainAudioEncoder(info, false);
        }

        try { if (playbackAudioRecord != null && playbackAudioRecord.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING) playbackAudioRecord.stop(); }
        catch (Exception ignored) {}

        boolean eosQueued = false;
        while (!eosQueued) {
            int inputIndex;
            try { inputIndex = audioEncoder.dequeueInputBuffer(10000); }
            catch (Exception e) { break; }
            if (inputIndex >= 0) {
                audioEncoder.queueInputBuffer(inputIndex, 0, 0, presentationTimeUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                eosQueued = true;
            }
            audioEos = drainAudioEncoder(info, true);
            if (audioEos) break;
        }
        while (!audioEos) audioEos = drainAudioEncoder(info, true);
    }

    private boolean drainAudioEncoder(MediaCodec.BufferInfo info, boolean waitForOutput) {
        int outputIndex;
        try { outputIndex = audioEncoder.dequeueOutputBuffer(info, waitForOutput ? 10000 : 0); }
        catch (Exception error) { return true; }
        if (outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
            try { audioTrack = muxerWriter.addTrack(audioEncoder.getOutputFormat(), false); }
            catch (Exception error) { notifyUser("Không thể tạo track âm thanh: " + error.getMessage()); }
        } else if (outputIndex >= 0) {
            ByteBuffer encoded = audioEncoder.getOutputBuffer(outputIndex);
            if (encoded != null && info.size > 0 && audioTrack >= 0
                    && (info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                try { muxerWriter.writeSample(audioTrack, encoded, info); }
                catch (Exception error) { notifyUser("Lỗi ghi âm thanh: " + error.getMessage()); }
            }
            boolean eos = (info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0;
            audioEncoder.releaseOutputBuffer(outputIndex, false);
            return eos;
        }
        return false;
    }

    private void showFloatingControls() {
        windowManager = (WindowManager)getSystemService(WINDOW_SERVICE);
        expandedView = buildExpandedView();
        int windowType = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        windowParams = new WindowManager.LayoutParams(dp(252), dp(86), windowType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        windowParams.gravity = Gravity.TOP | Gravity.LEFT;
        windowParams.x = dp(14);
        windowParams.y = dp(105);
        windowManager.addView(expandedView, windowParams);
        collapsed = false;
    }

    private LinearLayout buildExpandedView() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(7), dp(6), dp(7), dp(6));
        root.setBackground(background(0xF21B2633, 16));
        root.setElevation(dp(8));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(4), dp(1), dp(2), dp(1));

        expandedTitle = new TextView(this);
        expandedTitle.setText("●  BONES RECORDER  •  REC");
        expandedTitle.setTextColor(0xFFFF525D);
        expandedTitle.setTextSize(12);
        expandedTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        expandedTitle.setPadding(dp(8), dp(8), dp(10), dp(8));
        header.addView(expandedTitle, new LinearLayout.LayoutParams(0, -2, 1));
        installDrag(expandedTitle);

        Button collapse = controlButton("−", 0xFF354456, Color.WHITE);
        header.addView(collapse, new LinearLayout.LayoutParams(dp(36), dp(34)));
        collapse.setOnClickListener(v -> setCollapsed(true));
        root.addView(header, new LinearLayout.LayoutParams(-1, dp(42)));

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setGravity(Gravity.CENTER_VERTICAL);
        controls.setPadding(dp(2), dp(3), dp(2), 0);

        pauseButton = controlButton("TẠM DỪNG", 0xFF30475F, Color.WHITE);
        pauseButton.setOnClickListener(v -> {
            togglePause();
            pauseButton.setText(paused ? "TIẾP TỤC" : "TẠM DỪNG");
            updateOverlayText();
        });
        Button stop = controlButton("DỪNG", 0xFFB83D4B, Color.WHITE);
        stop.setOnClickListener(v -> stopRecording());

        LinearLayout.LayoutParams first = new LinearLayout.LayoutParams(0, dp(40), 1);
        first.setMargins(dp(2), 0, dp(3), 0);
        LinearLayout.LayoutParams second = new LinearLayout.LayoutParams(0, dp(40), 1);
        second.setMargins(dp(3), 0, dp(2), 0);
        controls.addView(pauseButton, first);
        controls.addView(stop, second);
        root.addView(controls, new LinearLayout.LayoutParams(-1, dp(44)));
        return root;
    }

    private View buildCollapsedView() {
        TextView bubble = new TextView(this);
        bubble.setText("●\nREC");
        bubble.setTextColor(Color.WHITE);
        bubble.setTextSize(11);
        bubble.setLineSpacing(-dp(1), 1f);
        bubble.setGravity(Gravity.CENTER);
        bubble.setTypeface(null, android.graphics.Typeface.BOLD);
        bubble.setBackground(background(0xF21B2633, 30));
        bubble.setElevation(dp(8));
        collapsedTitle = bubble;
        bubble.setTextColor(0xFFFF525D);
        installCollapsedDragAndTap(bubble);
        return bubble;
    }

    private void installCollapsedDragAndTap(View bubble) {
        bubble.setOnTouchListener(new View.OnTouchListener() {
            private float downX, downY;
            private int startX, startY;
            private boolean moved;
            @Override public boolean onTouch(View view, MotionEvent event) {
                if (windowParams == null) return true;
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = event.getRawX(); downY = event.getRawY();
                        startX = windowParams.x; startY = windowParams.y; moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx = (int)(event.getRawX() - downX);
                        int dy = (int)(event.getRawY() - downY);
                        if (Math.abs(dx) + Math.abs(dy) > dp(5)) moved = true;
                        if (moved) {
                            windowParams.x = startX + dx;
                            windowParams.y = startY + dy;
                            clampWindowPosition();
                            updateAttachedView();
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) setCollapsed(false);
                        return true;
                }
                return true;
            }
        });
    }

    private void installDrag(View dragHandle) {
        dragHandle.setOnTouchListener(new View.OnTouchListener() {
            private float downX, downY;
            private int startX, startY;
            private boolean moved;
            @Override public boolean onTouch(View view, MotionEvent event) {
                if (windowParams == null) return true;
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = event.getRawX(); downY = event.getRawY();
                        startX = windowParams.x; startY = windowParams.y; moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx = (int)(event.getRawX() - downX);
                        int dy = (int)(event.getRawY() - downY);
                        if (Math.abs(dx) + Math.abs(dy) > dp(4)) moved = true;
                        if (moved) {
                            windowParams.x = startX + dx;
                            windowParams.y = startY + dy;
                            clampWindowPosition();
                            updateAttachedView();
                        }
                        return true;
                    default:
                        return true;
                }
            }
        });
    }

    private void setCollapsed(boolean makeCollapsed) {
        if (collapsed == makeCollapsed || windowManager == null || windowParams == null) return;
        View oldView = collapsed ? collapsedTitle : expandedView;
        View newView;
        if (makeCollapsed) {
            newView = buildCollapsedView();
        } else {
            newView = expandedView;
        }
        try { windowManager.removeView(oldView); } catch (Exception ignored) {}
        collapsed = makeCollapsed;
        windowParams.width = makeCollapsed ? dp(60) : dp(252);
        windowParams.height = makeCollapsed ? dp(60) : dp(86);
        clampWindowPosition();
        try { windowManager.addView(newView, windowParams); }
        catch (Exception e) { notifyUser("Không thể thay đổi kích thước cửa sổ nổi."); }
        updateOverlayText();
    }

    private void updateAttachedView() {
        try { windowManager.updateViewLayout(collapsed ? collapsedTitle : expandedView, windowParams); }
        catch (Exception ignored) {}
    }

    private void clampWindowPosition() {
        if (windowManager == null || windowParams == null) return;
        DisplayMetrics metrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getRealMetrics(metrics);
        int width = collapsed ? dp(60) : dp(252);
        int height = collapsed ? dp(60) : dp(86);
        windowParams.width = width;
        windowParams.height = height;
        windowParams.x = Math.max(0, Math.min(windowParams.x, metrics.widthPixels - width));
        windowParams.y = Math.max(0, Math.min(windowParams.y, metrics.heightPixels - height));
    }

    private void updateOverlayText() {
        String shortText = paused ? "Ⅱ\nPAUSE" : "●\nREC";
        int color = paused ? 0xFFFFC857 : 0xFFFF525D;
        if (expandedTitle != null) {
            expandedTitle.setText(paused ? "Ⅱ  BONES RECORDER  •  TẠM DỪNG" : "●  BONES RECORDER  •  REC");
            expandedTitle.setTextColor(color);
        }
        if (collapsedTitle != null) {
            collapsedTitle.setText(shortText);
            collapsedTitle.setTextColor(color);
        }
    }

    private Button controlButton(String label, int backgroundColor, int foregroundColor) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextColor(foregroundColor);
        button.setTextSize(11);
        button.setTypeface(null, android.graphics.Typeface.BOLD);
        button.setAllCaps(false);
        button.setPadding(dp(5), 0, dp(5), 0);
        button.setMinHeight(dp(32));
        button.setBackground(background(backgroundColor, 10));
        return button;
    }

    private GradientDrawable background(int color, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radius));
        return drawable;
    }

    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }

    private void togglePause() {
        if (!recording || videoEncoder == null) return;
        boolean nextPaused = !paused;
        try {
            android.os.Bundle parameters = new android.os.Bundle();
            parameters.putInt(MediaCodec.PARAMETER_KEY_SUSPEND, nextPaused ? 1 : 0);
            videoEncoder.setParameters(parameters);
            if (recordInternalAudio && playbackAudioRecord != null) {
                if (nextPaused) {
                    if (playbackAudioRecord.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING)
                        playbackAudioRecord.stop();
                } else {
                    playbackAudioRecord.startRecording();
                    audioResumeGeneration++;
                }
            }
            paused = nextPaused;
            updateNotification(paused ? "Đang tạm dừng quay" : "Đang quay • MP4 • " +
                    (recordInternalAudio ? "Âm thanh nội bộ bật" : "Không âm thanh"));
        } catch (Exception e) {
            notifyUser("Không thể thay đổi trạng thái quay trên thiết bị này.");
        }
    }

    private void sendState(boolean isRecording) {
        Intent state = new Intent(ACTION_STATE);
        state.setPackage(getPackageName());
        state.putExtra(KEY_RECORDING, isRecording);
        sendBroadcast(state);
    }

    private void stopRecording() {
        if (stopping) return;
        stopping = true;
        stopRequested = true;
        if (paused && videoEncoder != null) {
            try { android.os.Bundle p = new android.os.Bundle(); p.putInt(MediaCodec.PARAMETER_KEY_SUSPEND, 0); videoEncoder.setParameters(p); } catch (Exception ignored) {}
            paused = false;
        }
        recording = false;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_RECORDING, false).apply();
        sendState(false);

        try { if (expandedView != null && windowManager != null) windowManager.removeView(expandedView); } catch (Exception ignored) {}
        try { if (collapsedTitle != null && windowManager != null) windowManager.removeView(collapsedTitle); } catch (Exception ignored) {}
        expandedView = null; collapsedTitle = null; expandedTitle = null; pauseButton = null;

        try { if (virtualDisplay != null) virtualDisplay.release(); } catch (Exception ignored) {}
        virtualDisplay = null;
        try { if (playbackAudioRecord != null && playbackAudioRecord.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING) playbackAudioRecord.stop(); }
        catch (Exception ignored) {}
        try { if (videoEncoder != null) videoEncoder.signalEndOfInputStream(); } catch (Exception ignored) {}

        new Thread(this::finalizeRecording, "BonesRecorderFinalize").start();
    }

    private void finalizeRecording() {
        joinQuietly(videoDrainThread, 10000);
        joinQuietly(audioEncodeThread, 10000);

        try { if (muxerWriter != null) muxerWriter.finish(); } catch (Exception ignored) {}
        try { if (audioEncoder != null) audioEncoder.stop(); } catch (Exception ignored) {}
        try { if (audioEncoder != null) audioEncoder.release(); } catch (Exception ignored) {}
        audioEncoder = null;
        try { if (videoEncoder != null) videoEncoder.stop(); } catch (Exception ignored) {}
        try { if (videoEncoder != null) videoEncoder.release(); } catch (Exception ignored) {}
        videoEncoder = null;
        try { if (videoInputSurface != null) videoInputSurface.release(); } catch (Exception ignored) {}
        videoInputSurface = null;
        releaseAudioCaptureQuietly();
        try { if (projection != null) projection.stop(); } catch (Exception ignored) {}
        projection = null;
        try { if (output != null) output.close(); } catch (Exception ignored) {}
        output = null;

        if (videoUri != null) {
            if (muxerWriter != null && muxerWriter.hasStarted() && Build.VERSION.SDK_INT >= 29) {
                ContentValues done = new ContentValues();
                done.put(MediaStore.Video.Media.IS_PENDING, 0);
                try { getContentResolver().update(videoUri, done, null, null); } catch (Exception ignored) {}
            } else if (muxerWriter == null || !muxerWriter.hasStarted()) {
                try { getContentResolver().delete(videoUri, null, null); } catch (Exception ignored) {}
            }
        }
        videoUri = null;
        new Handler(Looper.getMainLooper()).post(() -> {
            stopForeground(true);
            stopSelf();
        });
    }

    private void joinQuietly(Thread thread, long timeoutMs) {
        if (thread == null || thread == Thread.currentThread()) return;
        try { thread.join(timeoutMs); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }

    private void releaseAudioCaptureQuietly() {
        try { if (playbackAudioRecord != null) playbackAudioRecord.release(); } catch (Exception ignored) {}
        playbackAudioRecord = null;
    }

    private void notifyUser(String message) {
        new Handler(Looper.getMainLooper()).post(() -> Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG).show());
    }

    private Notification buildNotification(String message) {
        Intent stop = new Intent(this, RecorderService.class).setAction("STOP");
        PendingIntent stopPending = PendingIntent.getService(this, 1, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CHANNEL)
                .setContentTitle("Bones Recorder")
                .setContentText(message)
                .setSmallIcon(android.R.drawable.presence_video_online)
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(null, "Dừng quay", stopPending).build())
                .build();
    }

    private void updateNotification(String message) {
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(NOTIFICATION_ID, buildNotification(message));
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "Bones Recorder", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        }
    }

    @Override public void onDestroy() {
        if (!stopping) stopRecording();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    /** Coordinates encoder tracks and buffers until MediaMuxer is ready. */
    private final class MuxerWriter {
        private final MediaMuxer target;
        private final boolean expectsAudio;
        private final ArrayDeque<PendingSample> pendingSamples = new ArrayDeque<>();
        private boolean started;
        private int videoIndex = -1;
        private int audioIndex = -1;

        MuxerWriter(MediaMuxer muxer, boolean withAudio) {
            target = muxer;
            expectsAudio = withAudio;
        }

        synchronized int addTrack(MediaFormat format, boolean video) {
            if (video) {
                if (videoIndex < 0) videoIndex = target.addTrack(format);
                startIfReady();
                return videoIndex;
            } else {
                if (audioIndex < 0) audioIndex = target.addTrack(format);
                startIfReady();
                return audioIndex;
            }
        }

        private void startIfReady() {
            if (!started && videoIndex >= 0 && (!expectsAudio || audioIndex >= 0)) {
                target.start();
                started = true;
                while (!pendingSamples.isEmpty()) {
                    PendingSample sample = pendingSamples.removeFirst();
                    target.writeSampleData(sample.track, sample.data, sample.info);
                }
            }
        }

        synchronized void writeSample(int track, ByteBuffer source, MediaCodec.BufferInfo info) {
            if (info.size <= 0) return;
            if (started) {
                target.writeSampleData(track, source, info);
                return;
            }
            ByteBuffer duplicate = source.duplicate();
            duplicate.position(info.offset);
            duplicate.limit(info.offset + info.size);
            ByteBuffer copy = ByteBuffer.allocateDirect(info.size);
            copy.put(duplicate);
            copy.flip();
            MediaCodec.BufferInfo clonedInfo = new MediaCodec.BufferInfo();
            clonedInfo.set(0, info.size, info.presentationTimeUs, info.flags);
            pendingSamples.addLast(new PendingSample(track, copy, clonedInfo));
        }

        synchronized boolean hasStarted() { return started; }

        synchronized void finish() {
            if (started) {
                try { target.stop(); } catch (Exception ignored) {}
            }
            try { target.release(); } catch (Exception ignored) {}
            pendingSamples.clear();
        }
    }

    private static final class PendingSample {
        final int track;
        final ByteBuffer data;
        final MediaCodec.BufferInfo info;
        PendingSample(int track, ByteBuffer data, MediaCodec.BufferInfo info) {
            this.track = track; this.data = data; this.info = info;
        }
    }
}
