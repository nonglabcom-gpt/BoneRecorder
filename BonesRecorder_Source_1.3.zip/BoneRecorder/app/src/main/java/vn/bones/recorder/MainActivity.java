package vn.bones.recorder;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQUEST_OVERLAY = 10;
    private static final int REQUEST_CAPTURE = 11;
    private static final int REQUEST_AUDIO_PERMISSION = 12;
    private static final String ACTION_STATE = "vn.bones.recorder.STATE";
    private static final String PREFS = "bones_recorder";
    private static final String KEY_RECORDING = "recording";
    private static final String KEY_INTERNAL_AUDIO = "internal_audio";

    private static final int BG = Color.rgb(10, 16, 23);
    private static final int CARD = Color.rgb(22, 31, 42);
    private static final int MUTED = Color.rgb(157, 172, 188);
    private static final int WHITE = Color.rgb(244, 248, 252);
    private static final int GREEN = Color.rgb(37, 201, 137);
    private static final int RED = Color.rgb(244, 65, 76);

    private MediaProjectionManager projectionManager;
    private TextView status;
    private Button startButton;
    private Switch audioSwitch;
    private boolean receiverRegistered;
    private boolean pendingStartAfterAudioPermission;

    private final BroadcastReceiver stateReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            updateRecordingState(intent.getBooleanExtra(KEY_RECORDING, false));
        }
    };

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(0);
        projectionManager = (MediaProjectionManager)getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        buildInterface();
    }

    @Override protected void onResume() {
        super.onResume();
        IntentFilter filter = new IntentFilter(ACTION_STATE);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(stateReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(stateReceiver, filter);
        receiverRegistered = true;
        updateRecordingState(getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean(KEY_RECORDING, false));
    }

    @Override protected void onPause() {
        if (receiverRegistered) {
            try { unregisterReceiver(stateReceiver); } catch (Exception ignored) {}
            receiverRegistered = false;
        }
        super.onPause();
    }

    private void buildInterface() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(22), dp(30), dp(22), dp(28));
        scroll.addView(page, new ScrollView.LayoutParams(-1, -2));

        TextView brand = text("BONES RECORDER", 26, WHITE, true);
        brand.setLetterSpacing(0.055f);
        brand.setGravity(Gravity.CENTER);
        page.addView(brand, matchWrap());

        TextView subtitle = text("SCREEN RECORDER", 12, MUTED, true);
        subtitle.setLetterSpacing(0.16f);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subtitleLp = matchWrap();
        subtitleLp.topMargin = dp(7);
        page.addView(subtitle, subtitleLp);

        LinearLayout specCard = card();
        specCard.setOrientation(LinearLayout.HORIZONTAL);
        specCard.setGravity(Gravity.CENTER);
        specCard.setPadding(dp(8), dp(16), dp(8), dp(16));
        LinearLayout.LayoutParams specLp = matchWrap();
        specLp.topMargin = dp(26);
        page.addView(specCard, specLp);
        addSpec(specCard, "1080p", "TỐI ĐA");
        addDivider(specCard);
        addSpec(specCard, "30 FPS", "KHUNG HÌNH");
        addDivider(specCard);
        addSpec(specCard, "MP4", "ĐỊNH DẠNG");

        LinearLayout actionCard = card();
        actionCard.setOrientation(LinearLayout.VERTICAL);
        actionCard.setPadding(dp(19), dp(20), dp(19), dp(19));
        LinearLayout.LayoutParams actionLp = matchWrap();
        actionLp.topMargin = dp(20);
        page.addView(actionCard, actionLp);

        status = text("●  SẴN SÀNG QUAY", 14, GREEN, true);
        actionCard.addView(status, matchWrap());

        TextView description = text("Quay màn hình điện thoại rõ nét, lưu trực tiếp vào thư viện video.", 14, MUTED, false);
        description.setLineSpacing(dp(3), 1f);
        LinearLayout.LayoutParams descriptionLp = matchWrap();
        descriptionLp.topMargin = dp(11);
        actionCard.addView(description, descriptionLp);

        startButton = button("BẮT ĐẦU QUAY", GREEN, Color.rgb(5, 32, 24));
        startButton.setMinHeight(dp(56));
        LinearLayout.LayoutParams startLp = matchWrap();
        startLp.topMargin = dp(20);
        actionCard.addView(startButton, startLp);
        startButton.setOnClickListener(v -> checkPermissionsAndStart());

        LinearLayout settingsCard = card();
        settingsCard.setOrientation(LinearLayout.VERTICAL);
        settingsCard.setPadding(dp(18), dp(17), dp(18), dp(17));
        LinearLayout.LayoutParams settingsLp = matchWrap();
        settingsLp.topMargin = dp(16);
        page.addView(settingsCard, settingsLp);

        TextView settingsTitle = text("TÙY CHỌN", 12, MUTED, true);
        settingsTitle.setLetterSpacing(0.10f);
        settingsCard.addView(settingsTitle, matchWrap());

        LinearLayout audioRow = new LinearLayout(this);
        audioRow.setGravity(Gravity.CENTER_VERTICAL);
        audioRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams audioLp = matchWrap();
        audioLp.topMargin = dp(12);
        settingsCard.addView(audioRow, audioLp);

        LinearLayout audioText = new LinearLayout(this);
        audioText.setOrientation(LinearLayout.VERTICAL);
        audioRow.addView(audioText, new LinearLayout.LayoutParams(0, -2, 1));
        audioText.addView(text("Âm thanh nội bộ", 15, WHITE, true), wrapWrap());
        TextView audioHint = text("Thu âm thanh media/game · Không dùng micro", 11, MUTED, false);
        LinearLayout.LayoutParams hintLp = wrapWrap();
        hintLp.topMargin = dp(4);
        audioText.addView(audioHint, hintLp);

        audioSwitch = new Switch(this);
        audioSwitch.setTextOn("BẬT");
        audioSwitch.setTextOff("TẮT");
        audioSwitch.setTextColor(WHITE);
        audioSwitch.setChecked(getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean(KEY_INTERNAL_AUDIO, false));
        audioSwitch.setOnCheckedChangeListener((buttonView, checked) -> onInternalAudioChanged(checked));
        audioRow.addView(audioSwitch, wrapWrap());

        View separator = new View(this);
        separator.setBackgroundColor(0xFF354253);
        LinearLayout.LayoutParams separatorLp = new LinearLayout.LayoutParams(-1, dp(1));
        separatorLp.topMargin = dp(15);
        separatorLp.bottomMargin = dp(14);
        settingsCard.addView(separator, separatorLp);

        TextView tapTitle = text("HIỆU ỨNG CHẠM", 12, MUTED, true);
        tapTitle.setLetterSpacing(0.10f);
        settingsCard.addView(tapTitle, matchWrap());
        TextView tapInfo = text("Để video hiện vòng tròn tại vị trí bạn chạm, bật “Hiển thị lần chạm” trong Tùy chọn nhà phát triển của Android.", 13, WHITE, false);
        tapInfo.setLineSpacing(dp(3), 1f);
        LinearLayout.LayoutParams tapInfoLp = matchWrap();
        tapInfoLp.topMargin = dp(6);
        settingsCard.addView(tapInfo, tapInfoLp);
        Button developerButton = button("MỞ TÙY CHỌN NHÀ PHÁT TRIỂN", 0xFF354456, WHITE);
        LinearLayout.LayoutParams developerLp = matchWrap();
        developerLp.topMargin = dp(11);
        settingsCard.addView(developerButton, developerLp);
        developerButton.setOnClickListener(v -> {
            try { startActivity(new Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)); }
            catch (Exception e) { Toast.makeText(this, "Không mở được Tùy chọn nhà phát triển.", Toast.LENGTH_SHORT).show(); }
        });

        TextView note = text("Video được lưu tại Movies/BonesRecorder. Android sẽ yêu cầu xác nhận quay màn hình mỗi lần bắt đầu.", 12, MUTED, false);
        note.setLineSpacing(dp(3), 1f);
        LinearLayout.LayoutParams noteLp = matchWrap();
        noteLp.topMargin = dp(17);
        page.addView(note, noteLp);

        setContentView(scroll);
    }

    private void onInternalAudioChanged(boolean checked) {
        if (Build.VERSION.SDK_INT < 29 && checked) {
            setAudioSwitchSilently(false);
            Toast.makeText(this, "Âm thanh nội bộ cần Android 10 trở lên.", Toast.LENGTH_LONG).show();
            return;
        }
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_INTERNAL_AUDIO, checked).apply();
        if (checked && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingStartAfterAudioPermission = false;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_AUDIO_PERMISSION);
        }
    }

    private void setAudioSwitchSilently(boolean checked) {
        if (audioSwitch == null) return;
        audioSwitch.setOnCheckedChangeListener(null);
        audioSwitch.setChecked(checked);
        audioSwitch.setOnCheckedChangeListener((buttonView, value) -> onInternalAudioChanged(value));
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_INTERNAL_AUDIO, checked).apply();
    }

    private void checkPermissionsAndStart() {
        boolean internalAudio = audioSwitch != null && audioSwitch.isChecked();
        if (internalAudio && Build.VERSION.SDK_INT < 29) {
            Toast.makeText(this, "Ghi âm thanh nội bộ cần Android 10 trở lên.", Toast.LENGTH_LONG).show();
            return;
        }
        if (internalAudio && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingStartAfterAudioPermission = true;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_AUDIO_PERMISSION);
            return;
        }
        checkOverlayAndStart();
    }

    private void checkOverlayAndStart() {
        if (!Settings.canDrawOverlays(this)) {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivityForResult(i, REQUEST_OVERLAY);
        } else requestCapturePermission();
    }

    private void requestCapturePermission() {
        startActivityForResult(projectionManager.createScreenCaptureIntent(), REQUEST_CAPTURE);
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQUEST_AUDIO_PERMISSION) return;
        boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
        if (!granted) {
            setAudioSwitchSilently(false);
            Toast.makeText(this, "Chưa cấp quyền âm thanh. Quay video sẽ không có tiếng.", Toast.LENGTH_LONG).show();
        } else {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_INTERNAL_AUDIO, true).apply();
            if (audioSwitch != null && !audioSwitch.isChecked()) setAudioSwitchSilently(true);
            if (pendingStartAfterAudioPermission) checkOverlayAndStart();
        }
        pendingStartAfterAudioPermission = false;
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_OVERLAY) {
            if (Settings.canDrawOverlays(this)) requestCapturePermission();
            else Toast.makeText(this, "Cần cho phép hiển thị cửa sổ nổi để điều khiển khi quay.", Toast.LENGTH_LONG).show();
        } else if (requestCode == REQUEST_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                Intent service = new Intent(this, RecorderService.class);
                service.putExtra("resultCode", resultCode);
                service.putExtra("projectionData", data);
                service.putExtra("recordInternalAudio", audioSwitch != null && audioSwitch.isChecked());
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(service);
                else startService(service);
            } else Toast.makeText(this, "Bạn đã hủy quyền quay màn hình.", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateRecordingState(boolean recording) {
        if (status != null) {
            status.setText(recording ? "●  ĐANG QUAY" : "●  SẴN SÀNG QUAY");
            status.setTextColor(recording ? RED : GREEN);
        }
        if (startButton != null) {
            startButton.setText(recording ? "ĐANG QUAY MÀN HÌNH" : "BẮT ĐẦU QUAY");
            startButton.setEnabled(!recording);
            startButton.setAlpha(recording ? 0.65f : 1f);
        }
    }

    private LinearLayout card() {
        LinearLayout layout = new LinearLayout(this);
        layout.setBackground(round(CARD, 19));
        return layout;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setTypeface(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL);
        return view;
    }

    private Button button(String value, int backgroundColor, int foregroundColor) {
        Button button = new Button(this);
        button.setText(value);
        button.setTextSize(13);
        button.setTextColor(foregroundColor);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setAllCaps(false);
        button.setGravity(Gravity.CENTER);
        button.setBackground(round(backgroundColor, 13));
        button.setPadding(dp(12), dp(8), dp(12), dp(8));
        return button;
    }

    private void addSpec(LinearLayout parent, String value, String label) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(Gravity.CENTER);
        item.addView(text(value, 17, WHITE, true), wrapWrap());
        TextView caption = text(label, 9, MUTED, true);
        caption.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams captionLp = wrapWrap();
        captionLp.topMargin = dp(4);
        item.addView(caption, captionLp);
        parent.addView(item, new LinearLayout.LayoutParams(0, -2, 1));
    }

    private void addDivider(LinearLayout parent) {
        View divider = new View(this);
        divider.setBackgroundColor(0xFF3A4654);
        parent.addView(divider, new LinearLayout.LayoutParams(dp(1), dp(34)));
    }

    private GradientDrawable round(int color, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radius));
        return drawable;
    }

    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }
    private LinearLayout.LayoutParams matchWrap() { return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); }
    private LinearLayout.LayoutParams wrapWrap() { return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT); }
}
