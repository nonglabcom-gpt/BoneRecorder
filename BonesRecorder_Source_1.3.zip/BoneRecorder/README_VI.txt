BONES RECORDER 1.3 - ANDROID SOURCE

Tinh nang:
- Quay man hinh MP4 (H.264), toi da 1080p neu man hinh va thiet bi ho tro; 30 FPS muc tieu.
- Dieu khien noi co 2 kich thuoc co dinh: cua so mo rong va nut REC tron nho; nut REC co the keo di, cham de mo rong.
- Tam dung / tiep tuc / dung quay.
- Tieng trang thai chinh: "SẴN SÀNG QUAY" khi dung va "ĐANG QUAY" mau do khi quay.
- Tuy chon thu am thanh phat lai tu ung dung (Android 10+); khong thu micro.
- Hieu ung cham su dung tuy chon he thong Android "Hien thi lan cham" trong Tuy chon nha phat trien.
- Logo va ten Bones Recorder.
- Khong quang cao, khong tai khoan, khong quyen INTERNET.

GHI AM THANH NOI BO:
- Su dung AudioPlaybackCaptureConfiguration + AudioRecord + AAC encoder, khong dung MediaRecorder.AudioSource.MIC.
- Android van yeu cau quyen RECORD_AUDIO de su dung AudioPlaybackCapture. Quyen nay duoc Android dat ten la quyen micro, nhung ma nguon trong du an nay chi tao AudioRecord voi AudioPlaybackCaptureConfiguration, khong chon MIC.
- Chi thu duoc audio co usage MEDIA/GAME va nguon phat cho phep capture. Mot so app/video co the chan capture; khi do track am thanh co the im lang.
- Can Android 10 (API 29) tro len va nguoi dung phai dong y hop thoai chia se/quay man hinh.

BUILD:
- Android Gradle Plugin 8.6.1, Gradle 8.7, JDK 17, compileSdk 35.
- Workflow chinh nam tai .github/workflows/build.yml trong repository.
- APK GitHub Actions la debug APK. Neu chu ky debug thay doi giua cac lan build, Android co the yeu cau go ban cu truoc khi cai ban moi.

LUU Y KIEM THU:
- Du an can duoc build va thu nghiem tren may that. Encoder H.264/AAC, audio playback capture, pause/resume va chinh sach capture cua app phat audio phu thuoc thiet bi/Android.
- Khong co cach nao cam ket thu am thanh tu tat ca ung dung; app phat co the opt-out.
