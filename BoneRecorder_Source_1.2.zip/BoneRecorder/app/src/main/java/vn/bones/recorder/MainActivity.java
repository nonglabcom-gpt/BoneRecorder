package vn.bones.recorder;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQUEST_OVERLAY = 10;
    private static final int REQUEST_CAPTURE = 11;
    private static final int REQUEST_AUDIO = 12;
    private static final String ACTION_STATE = "vn.bones.recorder.STATE";
    private static final String PREFS = "bone_recorder";
    private static final String KEY_RECORDING = "recording";
    private static final String KEY_AUDIO = "record_audio";

    private static final int BG = Color.rgb(12, 18, 26);
    private static final int CARD = Color.rgb(23, 32, 43);
    private static final int MUTED = Color.rgb(160, 174, 190);
    private static final int WHITE = Color.rgb(245, 248, 252);
    private static final int ACCENT = Color.rgb(39, 190, 130);
    private static final int RED = Color.rgb(239, 68, 78);

    private MediaProjectionManager projectionManager;
    private TextView status;
    private Button startButton;
    private Switch audioSwitch;
    private boolean receiverRegistered = false;
    private boolean pendingStartAfterAudioPermission = false;

    private final BroadcastReceiver stateReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            updateRecordingState(intent.getBooleanExtra(KEY_RECORDING, false));
        }
    };

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(0);
        projectionManager = (MediaProjectionManager)getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        buildInterface();
    }

    @Override protected void onResume() {
        super.onResume();
        IntentFilter filter = new IntentFilter(ACTION_STATE);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(stateReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(stateReceiver, filter);
        receiverRegistered = true;
        updateRecordingState(getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean(KEY_RECORDING, false));
    }

    @Override protected void onPause() {
        if (receiverRegistered) {
            try { unregisterReceiver(stateReceiver); } catch (Exception ignored) {}
            receiverRegistered = false;
        }
        super.onPause();
    }

    private void buildInterface() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(22), dp(28), dp(22), dp(30));
        scroll.addView(page, new ScrollView.LayoutParams(-1, -2));

        TextView brand = text("BONE RECORDER", 27, WHITE, true);
        brand.setLetterSpacing(0.055f);
        brand.setGravity(Gravity.CENTER);
        page.addView(brand, matchWrap());

        TextView subtitle = text("QUAY MÀN HÌNH", 15, MUTED, false);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subLp = matchWrap();
        subLp.topMargin = dp(5);
        page.addView(subtitle, subLp);

        LinearLayout specCard = card();
        specCard.setOrientation(LinearLayout.HORIZONTAL);
        specCard.setGravity(Gravity.CENTER);
        specCard.setPadding(dp(8), dp(15), dp(8), dp(15));
        LinearLayout.LayoutParams specLp = matchWrap();
        specLp.topMargin = dp(26);
        page.addView(specCard, specLp);
        addSpec(specCard, "1080p", "ĐỘ PHÂN GIẢI");
        addDivider(specCard);
        addSpec(specCard, "30 FPS", "KHUNG HÌNH");
        addDivider(specCard);
        addSpec(specCard, "MP4", "ĐỊNH DẠNG");

        LinearLayout actionCard = card();
        actionCard.setOrientation(LinearLayout.VERTICAL);
        actionCard.setPadding(dp(18), dp(20), dp(18), dp(18));
        LinearLayout.LayoutParams actionLp = matchWrap();
        actionLp.topMargin = dp(22);
        page.addView(actionCard, actionLp);

        status = text("●  SẴN SÀNG QUAY", 13, ACCENT, true);
        actionCard.addView(status, matchWrap());

        TextView description = text("Ghi lại màn hình điện thoại với chất lượng Full HD.", 15, WHITE, false);
        description.setLineSpacing(dp(3), 1f);
        LinearLayout.LayoutParams descLp = matchWrap();
        descLp.topMargin = dp(10);
        actionCard.addView(description, descLp);

        Button start = button("BẮT ĐẦU QUAY", ACCENT, Color.rgb(7, 28, 23));
        startButton = start;
        LinearLayout.LayoutParams startLp = matchWrap();
        startLp.topMargin = dp(20);
        start.setMinHeight(dp(56));
        actionCard.addView(start, startLp);
        start.setOnClickListener(v -> checkPermissionsAndStart());

        LinearLayout settingsCard = card();
        settingsCard.setOrientation(LinearLayout.VERTICAL);
        settingsCard.setPadding(dp(18), dp(16), dp(18), dp(16));
        LinearLayout.LayoutParams settingsLp = matchWrap();
        settingsLp.topMargin = dp(16);
        page.addView(settingsCard, settingsLp);

        TextView settingsTitle = text("TÙY CHỌN GHI HÌNH", 12, MUTED, true);
        settingsCard.addView(settingsTitle, matchWrap());

        LinearLayout audioRow = new LinearLayout(this);
        audioRow.setGravity(Gravity.CENTER_VERTICAL);
        audioRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams audioLp = matchWrap();
        audioLp.topMargin = dp(12);
        settingsCard.addView(audioRow, audioLp);

        LinearLayout audioText = new LinearLayout(this);
        audioText.setOrientation(LinearLayout.VERTICAL);
        audioRow.addView(audioText, new LinearLayout.LayoutParams(0, -2, 1));
        audioText.addView(text("Ghi âm micro", 15, WHITE, true), wrapWrap());
        TextView audioHint = text("Mặc định tắt · chỉ bật khi bạn cần", 12, MUTED, false);
        LinearLayout.LayoutParams hintLp = wrapWrap();
        hintLp.topMargin = dp(3);
        audioText.addView(audioHint, hintLp);

        audioSwitch = new Switch(this);
        audioSwitch.setTextOn("BẬT");
        audioSwitch.setTextOff("TẮT");
        audioSwitch.setTextColor(WHITE);
        audioSwitch.setChecked(getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean(KEY_AUDIO, false));
        audioSwitch.setOnCheckedChangeListener((buttonView, checked) -> {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_AUDIO, checked).apply();
            if (checked && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                pendingStartAfterAudioPermission = false;
                requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_AUDIO);
            }
        });
        audioRow.addView(audioSwitch, wrapWrap());

        View separator = new View(this);
        separator.setBackgroundColor(0xFF354253);
        LinearLayout.LayoutParams sepLp = new LinearLayout.LayoutParams(-1, dp(1));
        sepLp.topMargin = dp(15);
        sepLp.bottomMargin = dp(13);
        settingsCard.addView(separator, sepLp);

        TextView tapTitle = text("HIỆU ỨNG CHẠM", 12, MUTED, true);
        settingsCard.addView(tapTitle, matchWrap());
        TextView tapInfo = text("Muốn hiện vòng tròn tại điểm chạm trong video, bật tùy chọn “Hiển thị lần chạm” trong Tùy chọn nhà phát triển của Android.", 13, WHITE, false);
        tapInfo.setLineSpacing(dp(3), 1f);
        LinearLayout.LayoutParams tapInfoLp = matchWrap();
        tapInfoLp.topMargin = dp(6);
        settingsCard.addView(tapInfo, tapInfoLp);
        Button developerButton = button("MỞ TÙY CHỌN NHÀ PHÁT TRIỂN", 0xFF354456, WHITE);
        LinearLayout.LayoutParams devLp = matchWrap();
        devLp.topMargin = dp(12);
        settingsCard.addView(developerButton, devLp);
        developerButton.setOnClickListener(v -> {
            try { startActivity(new Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)); }
            catch (Exception e) { Toast.makeText(this, "Không mở được cài đặt nhà phát triển.", Toast.LENGTH_SHORT).show(); }
        });

        TextView note = text("Android sẽ yêu cầu xác nhận quyền quay màn hình mỗi lần bắt đầu. Bạn có thể dừng quay bất cứ lúc nào bằng nút nổi.", 12, MUTED, false);
        note.setLineSpacing(dp(3), 1f);
        LinearLayout.LayoutParams noteLp = matchWrap();
        noteLp.topMargin = dp(17);
        page.addView(note, noteLp);

        setContentView(scroll);
    }

    private void checkPermissionsAndStart() {
        boolean audio = audioSwitch != null && audioSwitch.isChecked();
        if (audio && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingStartAfterAudioPermission = true;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_AUDIO);
            return;
        }
        checkOverlayAndStart();
    }

    private void checkOverlayAndStart() {
        if (!Settings.canDrawOverlays(this)) {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivityForResult(i, REQUEST_OVERLAY);
        } else requestCapturePermission();
    }

    private void requestCapturePermission() {
        startActivityForResult(projectionManager.createScreenCaptureIntent(), REQUEST_CAPTURE);
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_AUDIO) {
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            if (!granted) {
                audioSwitch.setOnCheckedChangeListener(null);
                audioSwitch.setChecked(false);
                audioSwitch.setOnCheckedChangeListener((buttonView, checked) -> {
                    getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_AUDIO, checked).apply();
                    if (checked && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
                        requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_AUDIO);
                });
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_AUDIO, false).apply();
                Toast.makeText(this, "Chưa cấp quyền micro. Quay sẽ không có âm thanh.", Toast.LENGTH_LONG).show();
            } else {
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_AUDIO, true).apply();
                if (pendingStartAfterAudioPermission) checkOverlayAndStart();
            }
            pendingStartAfterAudioPermission = false;
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_OVERLAY) {
            if (Settings.canDrawOverlays(this)) requestCapturePermission();
            else Toast.makeText(this, "Bạn cần cho phép hiển thị nút nổi để điều khiển khi quay.", Toast.LENGTH_LONG).show();
        } else if (requestCode == REQUEST_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                Intent service = new Intent(this, RecorderService.class);
                service.putExtra("resultCode", resultCode);
                service.putExtra("projectionData", data);
                service.putExtra("recordAudio", audioSwitch != null && audioSwitch.isChecked());
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(service);
                else startService(service);
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_RECORDING, true).apply();
                updateRecordingState(true);
            } else Toast.makeText(this, "Bạn đã hủy quyền quay màn hình.", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateRecordingState(boolean recording) {
        if (status != null) {
            status.setText(recording ? "●  ĐANG QUAY" : "●  SẴN SÀNG QUAY");
            status.setTextColor(recording ? RED : ACCENT);
        }
        if (startButton != null) {
            startButton.setText(recording ? "ĐANG QUAY MÀN HÌNH" : "BẮT ĐẦU QUAY");
            startButton.setEnabled(!recording);
            startButton.setAlpha(recording ? 0.65f : 1f);
        }
    }

    private LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setBackground(round(CARD, 20));
        return l;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setTypeface(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL);
        return t;
    }

    private Button button(String value, int background, int foreground) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextSize(13);
        b.setTextColor(foreground);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER);
        b.setBackground(round(background, 14));
        b.setPadding(dp(12), dp(8), dp(12), dp(8));
        return b;
    }

    private void addSpec(LinearLayout parent, String value, String label) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(Gravity.CENTER);
        item.addView(text(value, 17, WHITE, true), wrapWrap());
        TextView l = text(label, 9, MUTED, true);
        l.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lp = wrapWrap();
        lp.topMargin = dp(4);
        item.addView(l, lp);
        parent.addView(item, new LinearLayout.LayoutParams(0, -2, 1));
    }

    private void addDivider(LinearLayout parent) {
        View line = new View(this);
        line.setBackgroundColor(0xFF3A4654);
        parent.addView(line, new LinearLayout.LayoutParams(dp(1), dp(34)));
    }

    private GradientDrawable round(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }
    private LinearLayout.LayoutParams matchWrap() { return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); }
    private LinearLayout.LayoutParams wrapWrap() { return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT); }
}
