package vn.bones.recorder;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.content.ContentValues;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.MediaRecorder;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.FileDescriptor;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class RecorderService extends Service {
    private static final String CHANNEL = "bone_recording";
    private static final int NOTIFICATION_ID = 41;
    private static final String ACTION_STATE = "vn.bones.recorder.STATE";
    private static final String PREFS = "bone_recorder";
    private static final String KEY_RECORDING = "recording";

    private MediaProjection projection;
    private MediaRecorder recorder;
    private VirtualDisplay virtualDisplay;
    private android.os.ParcelFileDescriptor output;
    private Uri videoUri;
    private WindowManager windowManager;
    private LinearLayout expandedView;
    private LinearLayout collapsedView;
    private TextView expandedTitle;
    private TextView collapsedTitle;
    private Button collapseButton;
    private Button pauseButton;
    private WindowManager.LayoutParams windowParams;
    private boolean collapsed = false;
    private boolean recording = false;
    private boolean paused = false;
    private boolean stopping = false;
    private boolean recordAudio = false;

    @Override public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && "STOP".equals(intent.getAction())) {
            stopRecording();
            return START_NOT_STICKY;
        }
        if (intent != null && "TOGGLE".equals(intent.getAction())) {
            togglePause();
            return START_NOT_STICKY;
        }

        Notification notification = buildNotification("Đang chuẩn bị quay màn hình");
        if (Build.VERSION.SDK_INT >= 30) {
            int serviceTypes = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION;
            if (intent != null && intent.getBooleanExtra("recordAudio", false)) {
                serviceTypes |= ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE;
            }
            startForeground(NOTIFICATION_ID, notification, serviceTypes);
        } else if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else startForeground(NOTIFICATION_ID, notification);

        try {
            int resultCode = intent.getIntExtra("resultCode", Activity.RESULT_CANCELED);
            Intent data = intent.getParcelableExtra("projectionData");
            recordAudio = intent.getBooleanExtra("recordAudio", false);
            MediaProjectionManager manager = (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
            projection = manager.getMediaProjection(resultCode, data);
            startRecording();
        } catch (Exception e) {
            Toast.makeText(this, "Không thể bắt đầu quay: " + e.getMessage(), Toast.LENGTH_LONG).show();
            stopRecording();
        }
        return START_NOT_STICKY;
    }

    private void startRecording() throws Exception {
        DisplayMetrics metrics = new DisplayMetrics();
        WindowManager wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        if (Build.VERSION.SDK_INT >= 30) {
            android.view.WindowMetrics m = wm.getCurrentWindowMetrics();
            Rect b = m.getBounds();
            metrics.widthPixels = b.width();
            metrics.heightPixels = b.height();
            metrics.densityDpi = getResources().getDisplayMetrics().densityDpi;
        } else {
            wm.getDefaultDisplay().getRealMetrics(metrics);
        }

        int width = metrics.widthPixels;
        int height = metrics.heightPixels;
        float scale = Math.min(1f, 1920f / Math.max(width, height));
        width = Math.max(2, ((int)(width * scale)) & ~1);
        height = Math.max(2, ((int)(height * scale)) & ~1);

        String filename = "BoneRecorder_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".mp4";
        ContentValues values = new ContentValues();
        values.put(MediaStore.Video.Media.DISPLAY_NAME, filename);
        values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
        if (Build.VERSION.SDK_INT >= 29) {
            values.put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/BoneRecorder");
            values.put(MediaStore.Video.Media.IS_PENDING, 1);
        }
        videoUri = getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
        if (videoUri == null) throw new IllegalStateException("Không tạo được tệp video");
        output = getContentResolver().openFileDescriptor(videoUri, "w");
        if (output == null) throw new IllegalStateException("Không mở được tệp video");
        FileDescriptor fd = output.getFileDescriptor();

        if (Build.VERSION.SDK_INT >= 31) recorder = new MediaRecorder(this);
        else recorder = new MediaRecorder();
        if (recordAudio) {
            recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        }
        recorder.setVideoSource(MediaRecorder.VideoSource.SURFACE);
        recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
        if (recordAudio) {
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            recorder.setAudioSamplingRate(44100);
            recorder.setAudioChannels(1);
            recorder.setAudioEncodingBitRate(128000);
        }
        recorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
        recorder.setVideoSize(width, height);
        recorder.setVideoFrameRate(30);
        recorder.setVideoEncodingBitRate(6_000_000);
        recorder.setOutputFile(fd);
        recorder.prepare();

        projection.registerCallback(new MediaProjection.Callback() {
            @Override public void onStop() { stopRecording(); }
        }, new Handler(Looper.getMainLooper()));

        virtualDisplay = projection.createVirtualDisplay("BoneRecorder", width, height, metrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, recorder.getSurface(), null, null);
        recorder.start();
        recording = true;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_RECORDING, true).apply();
        sendState(true);
        showFloatingControls();
        updateNotification("Đang quay • MP4 • " + (recordAudio ? "Có âm thanh" : "Không âm thanh"));
    }

    private void showFloatingControls() {
        windowManager = (WindowManager)getSystemService(WINDOW_SERVICE);
        expandedView = buildExpandedView();
        collapsedView = buildCollapsedView();

        int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        windowParams = new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        windowParams.gravity = Gravity.TOP | Gravity.LEFT;
        windowParams.x = dp(14);
        windowParams.y = dp(105);
        windowManager.addView(expandedView, windowParams);
        collapsed = false;
    }

    private LinearLayout buildExpandedView() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(7), dp(7), dp(7), dp(7));
        root.setBackground(background(0xF21B2633, 16));
        root.setElevation(dp(8));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(4), dp(1), dp(2), dp(1));

        expandedTitle = new TextView(this);
        expandedTitle.setText("●  BONE RECORDER  •  REC");
        expandedTitle.setTextColor(0xFFFF525D);
        expandedTitle.setTextSize(12);
        expandedTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        expandedTitle.setPadding(dp(8), dp(9), dp(10), dp(9));
        header.addView(expandedTitle, new LinearLayout.LayoutParams(0, -2, 1));
        installDrag(expandedTitle);

        collapseButton = controlButton("−", 0xFF354456, Color.WHITE);
        header.addView(collapseButton, new LinearLayout.LayoutParams(dp(38), dp(36)));
        collapseButton.setOnClickListener(v -> setCollapsed(true));
        root.addView(header, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setPadding(dp(2), dp(7), dp(2), dp(1));

        pauseButton = controlButton("TẠM DỪNG", 0xFF30475F, Color.WHITE);
        pauseButton.setOnClickListener(v -> {
            togglePause();
            pauseButton.setText(paused ? "TIẾP TỤC" : "TẠM DỪNG");
            updateOverlayText();
        });
        Button stop = controlButton("DỪNG", 0xFFB83D4B, Color.WHITE);
        stop.setOnClickListener(v -> stopRecording());
        LinearLayout.LayoutParams p1 = new LinearLayout.LayoutParams(0, dp(42), 1);
        p1.setMargins(dp(2), 0, dp(3), 0);
        LinearLayout.LayoutParams p2 = new LinearLayout.LayoutParams(0, dp(42), 1);
        p2.setMargins(dp(3), 0, dp(2), 0);
        controls.addView(pauseButton, p1);
        controls.addView(stop, p2);
        root.addView(controls, new LinearLayout.LayoutParams(-1, -2));
        return root;
    }

    private LinearLayout buildCollapsedView() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.HORIZONTAL);
        root.setGravity(Gravity.CENTER_VERTICAL);
        root.setPadding(dp(5), dp(3), dp(4), dp(3));
        root.setBackground(background(0xF21B2633, 24));
        root.setElevation(dp(8));
        root.setLayoutParams(new ViewGroup.LayoutParams(dp(116), dp(44)));

        collapsedTitle = new TextView(this);
        collapsedTitle.setText("● REC");
        collapsedTitle.setTextColor(0xFFFF525D);
        collapsedTitle.setTextSize(12);
        collapsedTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        collapsedTitle.setGravity(Gravity.CENTER_VERTICAL);
        collapsedTitle.setPadding(dp(8), 0, dp(5), 0);
        root.addView(collapsedTitle, new LinearLayout.LayoutParams(0, -1, 1));
        installDrag(collapsedTitle);

        Button expand = controlButton("+", 0xFF354456, Color.WHITE);
        root.addView(expand, new LinearLayout.LayoutParams(dp(34), dp(34)));
        expand.setOnClickListener(v -> setCollapsed(false));
        return root;
    }

    private void installDrag(View dragHandle) {
        dragHandle.setOnTouchListener(new View.OnTouchListener() {
            private float downRawX, downRawY;
            private int startX, startY;
            private boolean moved;
            @Override public boolean onTouch(View view, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        downRawX = event.getRawX();
                        downRawY = event.getRawY();
                        startX = windowParams.x;
                        startY = windowParams.y;
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx = (int)(event.getRawX() - downRawX);
                        int dy = (int)(event.getRawY() - downRawY);
                        if (Math.abs(dx) + Math.abs(dy) > dp(3)) moved = true;
                        if (moved) {
                            windowParams.x = startX + dx;
                            windowParams.y = startY + dy;
                            clampWindowPosition();
                            updateAttachedView();
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        return true;
                }
                return true;
            }
        });
    }

    private void setCollapsed(boolean value) {
        if (collapsed == value || windowManager == null || windowParams == null) return;
        View oldView = collapsed ? collapsedView : expandedView;
        View newView = value ? collapsedView : expandedView;
        try { windowManager.removeView(oldView); } catch (Exception ignored) {}
        collapsed = value;
        windowParams.width = value ? dp(116) : WindowManager.LayoutParams.WRAP_CONTENT;
        windowParams.height = value ? dp(44) : WindowManager.LayoutParams.WRAP_CONTENT;
        clampWindowPosition();
        try { windowManager.addView(newView, windowParams); } catch (Exception ignored) {}
        updateOverlayText();
    }

    private void updateAttachedView() {
        try { windowManager.updateViewLayout(collapsed ? collapsedView : expandedView, windowParams); }
        catch (Exception ignored) {}
    }

    private void clampWindowPosition() {
        DisplayMetrics dm = new DisplayMetrics();
        if (Build.VERSION.SDK_INT >= 30) {
            Rect b = windowManager.getCurrentWindowMetrics().getBounds();
            dm.widthPixels = b.width();
            dm.heightPixels = b.height();
        } else windowManager.getDefaultDisplay().getRealMetrics(dm);
        int w = collapsed ? dp(116) : Math.min(dp(250), dm.widthPixels - dp(16));
        int h = collapsed ? dp(44) : dp(112);
        windowParams.x = Math.max(0, Math.min(windowParams.x, dm.widthPixels - w));
        windowParams.y = Math.max(0, Math.min(windowParams.y, dm.heightPixels - h));
    }

    private void updateOverlayText() {
        String title = paused ? "Ⅱ  TẠM DỪNG" : "●  REC";
        int color = paused ? 0xFFFFC857 : 0xFFFF525D;
        if (expandedTitle != null) {
            expandedTitle.setText(paused ? "Ⅱ  BONE RECORDER  •  PAUSE" : "●  BONE RECORDER  •  REC");
            expandedTitle.setTextColor(color);
        }
        if (collapsedTitle != null) {
            collapsedTitle.setText(title);
            collapsedTitle.setTextColor(color);
        }
    }

    private Button controlButton(String label, int bg, int fg) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(fg);
        b.setTextSize(12);
        b.setTypeface(null, android.graphics.Typeface.BOLD);
        b.setAllCaps(false);
        b.setPadding(dp(6), 0, dp(6), 0);
        b.setMinHeight(dp(34));
        b.setBackground(background(bg, 11));
        return b;
    }

    private GradientDrawable background(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }

    private void togglePause() {
        if (!recording || recorder == null) return;
        try {
            if (!paused) {
                recorder.pause();
                paused = true;
                updateNotification("Đã tạm dừng quay");
            } else {
                recorder.resume();
                paused = false;
                updateNotification("Đang quay • MP4 • " + (recordAudio ? "Có âm thanh" : "Không âm thanh"));
            }
        } catch (Exception e) {
            Toast.makeText(this, "Không thể thay đổi trạng thái quay.", Toast.LENGTH_SHORT).show();
        }
    }

    private void sendState(boolean value) {
        Intent state = new Intent(ACTION_STATE);
        state.setPackage(getPackageName());
        state.putExtra(KEY_RECORDING, value);
        sendBroadcast(state);
    }

    private void stopRecording() {
        if (stopping) return;
        stopping = true;
        try { if (recording && recorder != null) recorder.stop(); } catch (Exception ignored) {}
        recording = false;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_RECORDING, false).apply();
        sendState(false);
        try { if (expandedView != null && windowManager != null && expandedView.isAttachedToWindow()) windowManager.removeView(expandedView); } catch (Exception ignored) {}
        try { if (collapsedView != null && windowManager != null && collapsedView.isAttachedToWindow()) windowManager.removeView(collapsedView); } catch (Exception ignored) {}
        expandedView = null;
        collapsedView = null;
        expandedTitle = null;
        collapsedTitle = null;
        collapseButton = null;
        pauseButton = null;
        windowParams = null;
        try { if (virtualDisplay != null) virtualDisplay.release(); } catch (Exception ignored) {}
        virtualDisplay = null;
        try { if (recorder != null) recorder.reset(); } catch (Exception ignored) {}
        try { if (recorder != null) recorder.release(); } catch (Exception ignored) {}
        recorder = null;
        try { if (projection != null) projection.stop(); } catch (Exception ignored) {}
        projection = null;
        try { if (output != null) output.close(); } catch (Exception ignored) {}
        output = null;

        if (videoUri != null && Build.VERSION.SDK_INT >= 29) {
            ContentValues done = new ContentValues();
            done.put(MediaStore.Video.Media.IS_PENDING, 0);
            try { getContentResolver().update(videoUri, done, null, null); } catch (Exception ignored) {}
        }
        videoUri = null;
        stopForeground(true);
        stopSelf();
    }

    private Notification buildNotification(String message) {
        Intent stop = new Intent(this, RecorderService.class).setAction("STOP");
        PendingIntent stopPending = PendingIntent.getService(this, 1, stop, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CHANNEL)
                .setContentTitle("Bone Recorder")
                .setContentText(message)
                .setSmallIcon(android.R.drawable.presence_video_online)
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(null, "Dừng quay", stopPending).build())
                .build();
    }

    private void updateNotification(String message) {
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(NOTIFICATION_ID, buildNotification(message));
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "Bone Recorder", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        }
    }

    @Override public void onDestroy() {
        if (!stopping) stopRecording();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
