BONE RECORDER 1.2

Thay đổi:
- Cửa sổ nổi có hai kích thước riêng biệt: mở rộng và thu gọn cố định. Kéo nút thu gọn không làm thay đổi kích thước của nó.
- Thêm tùy chọn ghi âm micro. Mặc định tắt; khi bật, Android yêu cầu cấp quyền micro.
- Bỏ các dòng thông tin Điều khiển và Lưu video khỏi giao diện chính.
- Trạng thái ĐANG QUAY và REC hiển thị màu đỏ.
- Có hướng dẫn mở Tùy chọn nhà phát triển để bật Hiển thị lần chạm (Show taps).

Hiệu ứng chạm:
Android không cho ứng dụng ghi màn hình tự đọc mọi thao tác chạm của ứng dụng khác. Để hiện vòng tròn chạm, người dùng bật thủ công:
Cài đặt > Tùy chọn nhà phát triển > Hiển thị lần chạm (Show taps).
Tên mục có thể khác đôi chút tùy phiên bản One UI.

Âm thanh:
- Tắt: chỉ ghi hình, không thu micro.
- Bật: thu âm từ micro điện thoại. Android sẽ hiển thị yêu cầu quyền micro.

Video lưu trong Movies/BoneRecorder.
Yêu cầu Android 8.0 trở lên.
