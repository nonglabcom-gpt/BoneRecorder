BONES RECORDER 1.1 - DU AN ANDROID
Tinh nang: quay man hinh MP4, khong ghi am, toi da 1080p (khong upscale), 30 FPS, nut noi keo tha/thu gon, luu Movies/BoneRecorder.
Khong quang cao, khong tai khoan, khong quyen Internet.

Thay doi 1.1:
- Thiet ke lai giao dien chinh, sua loi cat chu va nut bat dau.
- Cua so noi co the keo tha bang cach giu phan tieu de.
- Nut - thu gon thanh vien dieu khien nho; nut + mo rong lai.
- Nut tam dung/tiep tuc va dung quay duoc lam ro hon.

Luu y:
- Android se hien hop thoai xac nhan quay man hinh moi lan.
- Can cap quyen hien thi tren ung dung khac de hien nut noi.
- Video luu trong Movies/BoneRecorder.
- Khong the ghi noi dung ma ung dung khac chu dong chan quay.
- Can kiem thu tren thiet bi that; do phan giai va toc do phu thuoc man hinh, phan cung va he thong.


BONES RECORDER 1.2
- Cửa sổ nổi có chiều rộng cố định ở cả chế độ thu gọn và mở rộng.
- Kéo thanh REC không làm thay đổi kích thước cửa sổ.
- Vị trí kéo được giới hạn trong vùng màn hình.
- Gỡ phần mô tả, thẻ thiết lập và đoạn hướng dẫn khỏi giao diện chính.


BONES RECORDER 1.3
- Khi thu gọn cửa sổ nổi, nhãn “● REC” chuyển sang màu đỏ để dễ nhận biết đang quay.
- Khi mở rộng cửa sổ, tiêu đề trở lại màu trắng.
- Khi tạm dừng, nhãn “Ⅱ PAUSE” vẫn màu trắng ở cả hai trạng thái.


Phiên bản 1.4:
- Tên ứng dụng: Bones REC.
- Giao diện hiển thị BONES RECORDER.
- Đã bỏ dòng SẴN SÀNG QUAY.
- Bổ sung ghi chú không có tính năng ghi âm.
- Nút nổi thu gọn hiển thị đầy đủ REC.
- Logo mới đồng bộ màu giao diện.

Phiên bản 1.9:
- Cân bằng lại khoảng cách phía trên nút bắt đầu quay.
- Thay logo ứng dụng bằng đúng thiết kế BONES do người dùng cung cấp (nền xanh, chữ trắng, chấm đỏ trong chữ O).

PHIEN BAN 1.9
- Cua so noi thu gon tu dong co kich thuoc theo noi dung, khong con khoang cach rong giua REC va nut mo rong.
- Nut mo rong (+) trong trang thai thu gon la hinh tron 30dp.
- Logo BONES duoc can lai theo truc doc; chu O co cham do o giua va font Lato Bold mem mai hon.


Cập nhật 1.9:
- Bỏ bộ ảnh logo launcher tùy chỉnh và tham chiếu icon trong manifest.
- Căn cạnh phải nút thu gọn thẳng hàng với cạnh phải nút DỪNG.
- Giảm một lần requestLayout dư thừa khi đổi trạng thái cửa sổ nổi.
- Giữ MediaRecorder H.264, 1080p tối đa, 30 FPS; không thêm thư viện hoặc tác vụ nền mới.


PHIEN BAN 2.0 - CHON HUONG QUAY
- Man hinh chinh co hai lua chon: QUAY DOC (1080x1920) va QUAY NGANG (1920x1080).
- Mac dinh la quay doc.
- Hay xoay dien thoai dung huong da chon truoc khi cap quyen quay.
- Huong va ty le video duoc co dinh cho ca file MP4 trong lan quay do.
- 30 FPS, H.264, MP4, khong ghi am.


PHIEN BAN 2.2 - TOI UU ADAPTIVE
- Giu nguyen giao dien va cac thao tac cua phien ban 2.1.
- Tu doc kich thuoc man hinh thuc te; giu ti le goc, khong phong to (upscale), gioi han canh dai 1920 px va canh ngan 1080 px.
- Bitrate H.264 tu dieu chinh theo so pixel (1.2-6 Mbps), 30 FPS, MP4, khong ghi am.
- Chuyen khoi tao, pause/resume va giai phong MediaRecorder sang HandlerThread rieng de giam cong viec tren luong giao dien.
- Chi cong bo video vao thu vien khi MediaRecorder ket thuc thanh cong; xoa tep tam neu ket thuc that bai.
- Loai bo OrientationAwareRecorder khong duoc su dung; chi giu mot duong quay MediaRecorder.
- Tang versionCode len 11, versionName 2.2.

Luu y kiem thu: can build va thu tren thiet bi Android that. Do phan giai, bitrate thuc te, nhiet do va muc su dung CPU/GPU phu thuoc vao man hinh, chip ma hoa va ung dung dang quay.


PHIEN BAN 2.2.1 - OPTIMIZED
- Lam ro tren giao dien rang do phan giai dau ra toi da la 1080p; kich thuoc thuc te van phu thuoc man hinh va huong quay da chon.
- Bo import khong su dung trong RecorderService.
- Bo bien FileDescriptor trung gian; truyen truc tiep descriptor vao MediaRecorder.
- Chan yeu cau khoi dong quay lap lai tren cung mot service instance de tranh tao nhieu phien MediaProjection/MediaRecorder chong cheo.
- Kiem tra MediaProjection null som va bao loi ro rang neu khong tao duoc phien quay.
- Giu nguyen H.264, MP4, 30 FPS, bitrate adaptive, gioi han toi da 1080p, khong ghi am va giao dien nut noi.
- Tang versionCode len 12, versionName 2.2.1.

Kiem thu can thuc hien tren thiet bi that:
- Quay doc va quay ngang tren man hinh thuc te.
- Quay, tam dung, tiep tuc va dung; kiem tra video trong Movies/BoneRecorder.
- Thu huy quyen quay tu thong bao/he thong trong luc dang quay.
- Nhan bat dau nhieu lan lien tiep de xac nhan khong tao phien quay trung lap.
- Kiem tra video tren thiet bi co kich thuoc man hinh khac nhau.
