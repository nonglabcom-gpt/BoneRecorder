package vn.bones.recorder;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQUEST_OVERLAY = 10;
    private static final int REQUEST_CAPTURE = 11;
    private static final int BG = Color.rgb(13, 19, 27);
    private static final int CARD = Color.rgb(23, 32, 43);
    private static final int MUTED = Color.rgb(166, 180, 194);
    private static final int WHITE = Color.rgb(245, 248, 252);
    private static final int ACCENT = Color.rgb(40, 190, 130);
    private MediaProjectionManager projectionManager;
    private boolean landscapeSelected = false;
    private Button portraitButton;
    private Button landscapeButton;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (savedInstanceState != null) {
            landscapeSelected = savedInstanceState.getBoolean("landscapeSelected", false);
        }
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(0);
        projectionManager = (MediaProjectionManager)getSystemService(Context.MEDIA_PROJECTION_SERVICE);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(22), dp(24), dp(22), dp(28));
        scroll.addView(page, new ScrollView.LayoutParams(-1, -2));

        TextView brand = text("BONES RECORDER", 27, WHITE, true);
        brand.setLetterSpacing(0.06f);
        brand.setGravity(Gravity.CENTER);
        page.addView(brand, matchWrap());

        TextView subtitle = text("QUAY MÀN HÌNH", 15, MUTED, false);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subLp = matchWrap();
        subLp.topMargin = dp(7);
        page.addView(subtitle, subLp);

        LinearLayout specCard = card();
        specCard.setOrientation(LinearLayout.HORIZONTAL);
        specCard.setGravity(Gravity.CENTER);
        specCard.setPadding(dp(10), dp(14), dp(10), dp(14));
        LinearLayout.LayoutParams specLp = matchWrap();
        specLp.topMargin = dp(34);
        page.addView(specCard, specLp);
        addSpec(specCard, "≤1080p", "ĐỘ PHÂN GIẢI");
        addDivider(specCard);
        addSpec(specCard, "30 FPS", "KHUNG HÌNH");
        addDivider(specCard);
        addSpec(specCard, "MP4", "ĐỊNH DẠNG");

        TextView orientationLabel = text("CHỌN HƯỚNG QUAY", 12, MUTED, true);
        LinearLayout.LayoutParams orientationLabelLp = matchWrap();
        orientationLabelLp.topMargin = dp(24);
        orientationLabelLp.bottomMargin = dp(9);
        page.addView(orientationLabel, orientationLabelLp);

        LinearLayout orientationRow = new LinearLayout(this);
        orientationRow.setOrientation(LinearLayout.HORIZONTAL);
        orientationRow.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams orientationRowLp = matchWrap();
        page.addView(orientationRow, orientationRowLp);

        portraitButton = button("QUAY DỌC", 0xFF30475F, WHITE);
        landscapeButton = button("QUAY NGANG", 0xFF30475F, WHITE);
        styleOrientationButton(portraitButton);
        styleOrientationButton(landscapeButton);
        LinearLayout.LayoutParams orientationButtonLp = new LinearLayout.LayoutParams(0, dp(62), 1);
        orientationButtonLp.rightMargin = dp(5);
        orientationRow.addView(portraitButton, orientationButtonLp);
        LinearLayout.LayoutParams landscapeLp = new LinearLayout.LayoutParams(0, dp(62), 1);
        landscapeLp.leftMargin = dp(5);
        orientationRow.addView(landscapeButton, landscapeLp);
        portraitButton.setOnClickListener(v -> {
            landscapeSelected = false;
            updateOrientationButtons();
        });
        landscapeButton.setOnClickListener(v -> {
            landscapeSelected = true;
            updateOrientationButtons();
        });
        updateOrientationButtons();

        LinearLayout actionCard = card();
        actionCard.setOrientation(LinearLayout.VERTICAL);
        actionCard.setPadding(dp(18), dp(14), dp(18), dp(16));
        LinearLayout.LayoutParams actionLp = matchWrap();
        actionLp.topMargin = dp(30);
        page.addView(actionCard, actionLp);

        Button start = button("BẮT ĐẦU QUAY MÀN HÌNH", ACCENT, Color.rgb(7, 28, 23));
        LinearLayout.LayoutParams startLp = matchWrap();
        startLp.topMargin = dp(4);
        start.setMinHeight(dp(60));
        actionCard.addView(start, startLp);
        start.setOnClickListener(v -> checkOverlayAndStart());

        TextView audioNote = text("Phần mềm này không có tính năng ghi âm", 12, MUTED, false);
        audioNote.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams noteLp = matchWrap();
        noteLp.topMargin = dp(18);
        noteLp.leftMargin = dp(8);
        noteLp.rightMargin = dp(8);
        page.addView(audioNote, noteLp);

        setContentView(scroll);
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        outState.putBoolean("landscapeSelected", landscapeSelected);
        super.onSaveInstanceState(outState);
    }

    private void styleOrientationButton(Button button) {
        button.setTextSize(13);
        button.setSingleLine(true);
        button.setIncludeFontPadding(false);
        button.setMinWidth(0);
        button.setMinHeight(dp(62));
        button.setPadding(dp(4), 0, dp(4), 0);
        button.setGravity(Gravity.CENTER);
    }

    private void updateOrientationButtons() {
        if (portraitButton == null || landscapeButton == null) return;
        portraitButton.setBackground(round(landscapeSelected ? 0xFF30475F : ACCENT, 14));
        portraitButton.setTextColor(landscapeSelected ? WHITE : Color.rgb(7, 28, 23));
        landscapeButton.setBackground(round(landscapeSelected ? ACCENT : 0xFF30475F, 14));
        landscapeButton.setTextColor(landscapeSelected ? Color.rgb(7, 28, 23) : WHITE);
    }

    private void checkOverlayAndStart() {
        if (!Settings.canDrawOverlays(this)) {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivityForResult(i, REQUEST_OVERLAY);
        } else requestCapturePermission();
    }

    private void requestCapturePermission() {
        startActivityForResult(projectionManager.createScreenCaptureIntent(), REQUEST_CAPTURE);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_OVERLAY) {
            if (Settings.canDrawOverlays(this)) requestCapturePermission();
            else Toast.makeText(this, "Bạn cần cho phép hiển thị nút nổi để điều khiển khi quay.", Toast.LENGTH_LONG).show();
        } else if (requestCode == REQUEST_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                Intent service = new Intent(this, RecorderService.class);
                service.putExtra("resultCode", resultCode);
                service.putExtra("projectionData", data);
                service.putExtra("landscape", landscapeSelected);
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(service);
                else startService(service);
            } else Toast.makeText(this, "Bạn đã hủy quyền quay màn hình.", Toast.LENGTH_SHORT).show();
        }
    }

    private LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setBackground(round(CARD, 20));
        return l;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setTypeface(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL);
        return t;
    }

    private Button button(String value, int background, int foreground) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextSize(14);
        b.setTextColor(foreground);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER);
        b.setBackground(round(background, 14));
        b.setPadding(dp(12), dp(8), dp(12), dp(8));
        return b;
    }

    private void addSpec(LinearLayout parent, String value, String label) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(Gravity.CENTER);
        TextView v = text(value, 17, WHITE, true);
        TextView l = text(label, 9, MUTED, true);
        l.setGravity(Gravity.CENTER);
        item.addView(v, wrapWrap());
        LinearLayout.LayoutParams lp = wrapWrap();
        lp.topMargin = dp(4);
        item.addView(l, lp);
        parent.addView(item, new LinearLayout.LayoutParams(0, -2, 1));
    }

    private void addDivider(LinearLayout parent) {
        View line = new View(this);
        line.setBackgroundColor(0xFF3A4654);
        parent.addView(line, new LinearLayout.LayoutParams(dp(1), dp(34)));
    }

    private GradientDrawable round(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }
    private LinearLayout.LayoutParams matchWrap() { return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); }
    private LinearLayout.LayoutParams wrapWrap() { return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT); }
}
