package vn.bones.recorder;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.MediaRecorder;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.*;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.WindowManager;
import android.view.Display;
import android.graphics.PixelFormat;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.util.DisplayMetrics;
import android.widget.LinearLayout;
import android.widget.Button;
import android.widget.Toast;
import android.content.ContentValues;
import android.net.Uri;
import java.io.FileDescriptor;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class RecorderService extends Service {
    private static final String CHANNEL = "bone_recording";
    private static final int NOTIFICATION_ID = 41;
    private MediaProjection projection;
    private MediaRecorder recorder;
    private VirtualDisplay virtualDisplay;
    private android.os.ParcelFileDescriptor output;
    private Uri videoUri;
    private WindowManager windowManager;
    private LinearLayout floatingBar;
    private LinearLayout floatingHeader;
    private LinearLayout floatingControls;
    private TextView floatingTitle;
    private Button collapseButton;
    private WindowManager.LayoutParams floatingParams;
    private boolean collapsed = false;
    private boolean recording = false;
    private boolean paused = false;
    private boolean stopping = false;
    private boolean landscapeRecording = false;
    private boolean recordingStarted = false;
    private DisplayManager displayManager;
    private DisplayManager.DisplayListener displayListener;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private int lastDisplayWidth;
    private int lastDisplayHeight;
    private int lastDensityDpi;
    private int lastDisplayRotation;

    @Override public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && "STOP".equals(intent.getAction())) {
            stopRecording();
            return START_NOT_STICKY;
        }
        if (intent != null && "TOGGLE".equals(intent.getAction())) {
            togglePause();
            return START_NOT_STICKY;
        }
        if (intent == null) {
            stopSelf();
            return START_NOT_STICKY;
        }

        Notification notification = buildNotification("Đang chuẩn bị quay màn hình");
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else startForeground(NOTIFICATION_ID, notification);

        try {
            int resultCode = intent.getIntExtra("resultCode", Activity.RESULT_CANCELED);
            Intent data = intent.getParcelableExtra("projectionData");
            MediaProjectionManager manager =
                    (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
            projection = manager.getMediaProjection(resultCode, data);
            landscapeRecording = intent.getBooleanExtra("landscape", false);
            startRecording();
        } catch (Exception e) {
            Toast.makeText(this, "Không thể bắt đầu quay: " + e.getMessage(), Toast.LENGTH_LONG).show();
            stopRecording();
        }
        return START_NOT_STICKY;
    }

    private void startRecording() throws Exception {
        DisplayMetrics metrics = new DisplayMetrics();
        WindowManager wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        // Use the physical display size, not app-window bounds (which can exclude
        // system bars and cause the captured game to appear scaled down).
        wm.getDefaultDisplay().getRealMetrics(metrics);
        if (metrics.widthPixels <= 0 || metrics.heightPixels <= 0 || metrics.densityDpi <= 0) {
            throw new IllegalStateException("Không đọc được kích thước màn hình");
        }

        // Keep the selected video canvas stable. The mirrored VirtualDisplay follows
        // the real screen dimensions when the user rotates the phone during recording.
        int width = landscapeRecording ? 1920 : 1080;
        int height = landscapeRecording ? 1080 : 1920;

        String filename = "BoneRecorder_" +
                new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".mp4";
        ContentValues values = new ContentValues();
        values.put(MediaStore.Video.Media.DISPLAY_NAME, filename);
        values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
        if (Build.VERSION.SDK_INT >= 29)
            values.put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/BoneRecorder");
        if (Build.VERSION.SDK_INT >= 29)
            values.put(MediaStore.Video.Media.IS_PENDING, 1);

        videoUri = getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
        if (videoUri == null) throw new IllegalStateException("Không tạo được tệp video");
        output = getContentResolver().openFileDescriptor(videoUri, "w");
        FileDescriptor fd = output.getFileDescriptor();

        if (Build.VERSION.SDK_INT >= 31) recorder = new MediaRecorder(this);
        else recorder = new MediaRecorder();
        recorder.setVideoSource(MediaRecorder.VideoSource.SURFACE);
        recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
        recorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
        recorder.setVideoSize(width, height);
        recorder.setVideoFrameRate(30);
        recorder.setVideoEncodingBitRate(6_000_000);
        recorder.setOutputFile(fd);
        recorder.prepare();

        projection.registerCallback(new MediaProjection.Callback() {
            @Override public void onStop() { stopRecording(); }
        }, new Handler(Looper.getMainLooper()));

        // VirtualDisplay dimensions follow the actual physical display. MediaRecorder
        // still encodes the user-selected fixed canvas (portrait or landscape).
        virtualDisplay = projection.createVirtualDisplay("BonesRecorder",
                metrics.widthPixels, metrics.heightPixels, metrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                recorder.getSurface(), null, mainHandler);
        lastDisplayWidth = metrics.widthPixels;
        lastDisplayHeight = metrics.heightPixels;
        lastDensityDpi = metrics.densityDpi;
        lastDisplayRotation = wm.getDefaultDisplay().getRotation();
        recorder.start();
        recording = true;
        recordingStarted = true;
        registerDisplayResizeListener();
        showFloatingControls();
        updateNotification("Đang quay • MP4 • Không âm thanh");
    }

    /**
     * Keep the mirrored display aligned with the phone's real dimensions after
     * a 90/270-degree rotation. The encoded MP4 canvas remains fixed to the mode
     * selected before recording; Android scales the mirrored display into it.
     */
    private void registerDisplayResizeListener() {
        displayManager = (DisplayManager)getSystemService(DISPLAY_SERVICE);
        if (displayManager == null || displayListener != null) return;
        displayListener = new DisplayManager.DisplayListener() {
            @Override public void onDisplayAdded(int displayId) { }
            @Override public void onDisplayRemoved(int displayId) { }
            @Override public void onDisplayChanged(int displayId) {
                if (displayId != Display.DEFAULT_DISPLAY || stopping || virtualDisplay == null) return;
                Display display = displayManager.getDisplay(Display.DEFAULT_DISPLAY);
                if (display == null) return;
                DisplayMetrics current = new DisplayMetrics();
                display.getRealMetrics(current);
                if (current.widthPixels <= 0 || current.heightPixels <= 0 || current.densityDpi <= 0) return;
                int rotation = display.getRotation();
                if (current.widthPixels == lastDisplayWidth
                        && current.heightPixels == lastDisplayHeight
                        && current.densityDpi == lastDensityDpi
                        && rotation == lastDisplayRotation) return;
                try {
                    virtualDisplay.resize(current.widthPixels, current.heightPixels, current.densityDpi);
                    lastDisplayWidth = current.widthPixels;
                    lastDisplayHeight = current.heightPixels;
                    lastDensityDpi = current.densityDpi;
                    lastDisplayRotation = rotation;
                } catch (RuntimeException ignored) {
                    // A transient resize during projection shutdown is harmless;
                    // the normal stop path releases the display and recorder.
                }
            }
        };
        displayManager.registerDisplayListener(displayListener, mainHandler);
    }

    private void unregisterDisplayResizeListener() {
        if (displayManager != null && displayListener != null) {
            try { displayManager.unregisterDisplayListener(displayListener); }
            catch (Exception ignored) { }
        }
        displayListener = null;
        displayManager = null;
    }

    private void showFloatingControls() {
        windowManager = (WindowManager)getSystemService(WINDOW_SERVICE);
        floatingBar = new LinearLayout(this);
        floatingBar.setOrientation(LinearLayout.VERTICAL);
        floatingBar.setPadding(dp(4), dp(4), dp(4), dp(4));
        floatingBar.setBackground(background(0xF21B2633, 18));
        floatingBar.setElevation(dp(8));

        floatingHeader = new LinearLayout(this);
        floatingHeader.setOrientation(LinearLayout.HORIZONTAL);
        floatingHeader.setGravity(Gravity.CENTER_VERTICAL);
        // Match the collapse button right edge to the STOP button right edge.
        // Controls use 3dp inner padding + 3dp button margin; mirror that 6dp here.
        floatingHeader.setPadding(dp(2), dp(1), dp(6), dp(1));

        floatingTitle = new TextView(this);
        floatingTitle.setText("●  BONES RECORDER");
        floatingTitle.setTextColor(Color.WHITE);
        floatingTitle.setTextSize(12);
        floatingTitle.setSingleLine(true);
        floatingTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        floatingTitle.setPadding(dp(6), dp(8), dp(6), dp(8));
        floatingHeader.addView(floatingTitle, new LinearLayout.LayoutParams(0, -2, 1));

        collapseButton = controlButton("−", 0xFF354456, Color.WHITE);
        floatingHeader.addView(collapseButton, new LinearLayout.LayoutParams(dp(42), dp(38)));
        collapseButton.setOnClickListener(v -> setCollapsed(!collapsed));
        floatingTitle.setOnTouchListener(new View.OnTouchListener() {
            private float downRawX, downRawY;
            private int startX, startY;
            private boolean moved;
            @Override public boolean onTouch(View view, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        downRawX = event.getRawX();
                        downRawY = event.getRawY();
                        startX = floatingParams.x;
                        startY = floatingParams.y;
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx = (int)(event.getRawX() - downRawX);
                        int dy = (int)(event.getRawY() - downRawY);
                        if (Math.abs(dx) + Math.abs(dy) > dp(4)) moved = true;
                        if (moved) {
                            DisplayMetrics screen = getResources().getDisplayMetrics();
                            int viewWidth = floatingBar.getWidth();
                            int viewHeight = Math.max(floatingBar.getHeight(), dp(40));
                            int maxX = Math.max(0, screen.widthPixels - viewWidth);
                            int maxY = Math.max(0, screen.heightPixels - viewHeight);
                            floatingParams.x = Math.max(0, Math.min(maxX, startX + dx));
                            floatingParams.y = Math.max(0, Math.min(maxY, startY + dy));
                            try { windowManager.updateViewLayout(floatingBar, floatingParams); } catch (Exception ignored) {}
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        return true;
                }
                return true;
            }
        });
        floatingBar.addView(floatingHeader, new LinearLayout.LayoutParams(-1, -2));

        floatingControls = new LinearLayout(this);
        floatingControls.setOrientation(LinearLayout.HORIZONTAL);
        floatingControls.setPadding(dp(3), dp(7), dp(3), dp(2));

        Button pause = controlButton("TẠM DỪNG", 0xFF30475F, Color.WHITE);
        pause.setOnClickListener(v -> {
            togglePause();
            pause.setText(paused ? "TIẾP TỤC" : "TẠM DỪNG");
            updateFloatingTitle();
        });
        Button stop = controlButton("DỪNG", 0xFFB83D4B, Color.WHITE);
        stop.setOnClickListener(v -> stopRecording());
        LinearLayout.LayoutParams pauseLp = new LinearLayout.LayoutParams(0, dp(44), 1);
        pauseLp.setMargins(dp(3), 0, dp(3), 0);
        LinearLayout.LayoutParams stopLp = new LinearLayout.LayoutParams(0, dp(44), 1);
        stopLp.setMargins(dp(3), 0, dp(3), 0);
        floatingControls.addView(pause, pauseLp);
        floatingControls.addView(stop, stopLp);
        floatingBar.addView(floatingControls, new LinearLayout.LayoutParams(-1, -2));

        int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        floatingParams = new WindowManager.LayoutParams(
                dp(236),
                WindowManager.LayoutParams.WRAP_CONTENT,
                type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        floatingParams.gravity = Gravity.TOP | Gravity.LEFT;
        floatingParams.x = dp(16);
        floatingParams.y = dp(110);
        windowManager.addView(floatingBar, floatingParams);
    }

    private void setCollapsed(boolean value) {
        collapsed = value;
        floatingControls.setVisibility(collapsed ? View.GONE : View.VISIBLE);

        // Compact mode wraps its content: REC sits close to a circular expand button.
        floatingParams.width = collapsed
                ? WindowManager.LayoutParams.WRAP_CONTENT : dp(236);
        floatingParams.height = WindowManager.LayoutParams.WRAP_CONTENT;

        floatingBar.setPadding(dp(collapsed ? 3 : 4), dp(collapsed ? 3 : 4),
                dp(collapsed ? 3 : 4), dp(collapsed ? 3 : 4));
        floatingBar.setBackground(background(collapsed ? 0x991B2633 : 0xF21B2633,
                collapsed ? 22 : 18));
        floatingHeader.setPadding(dp(collapsed ? 1 : 2), dp(1),
                dp(collapsed ? 1 : 6), dp(1));

        floatingTitle.setTextSize(collapsed ? 11 : 12);
        floatingTitle.setPadding(dp(collapsed ? 4 : 6), dp(collapsed ? 5 : 8),
                dp(collapsed ? 2 : 6), dp(collapsed ? 5 : 8));
        LinearLayout.LayoutParams titleParams = collapsed
                ? new LinearLayout.LayoutParams(-2, -2)
                : new LinearLayout.LayoutParams(0, -2, 1);
        floatingTitle.setLayoutParams(titleParams);

        LinearLayout.LayoutParams buttonSize = new LinearLayout.LayoutParams(
                dp(collapsed ? 30 : 42), dp(collapsed ? 30 : 38));
        if (collapsed) buttonSize.leftMargin = dp(2);
        collapseButton.setLayoutParams(buttonSize);
        collapseButton.setBackground(background(0xB83A4B60, collapsed ? 100 : 12));
        collapseButton.setTextSize(collapsed ? 17 : 18);
        collapseButton.setPadding(0, 0, 0, dp(collapsed ? 2 : 0));

        updateFloatingTitle();
        collapseButton.setText(collapsed ? "+" : "−");
        floatingBar.requestLayout();
        try { windowManager.updateViewLayout(floatingBar, floatingParams); } catch (Exception ignored) {}
    }

    private void updateFloatingTitle() {
        if (floatingTitle == null) return;
        if (paused) {
            floatingTitle.setText("Ⅱ  PAUSE");
            floatingTitle.setTextColor(Color.WHITE);
        } else if (collapsed) {
            floatingTitle.setText("●  REC");
            floatingTitle.setTextColor(0xFFFF5252);
        } else {
            floatingTitle.setText("●  BONES RECORDER");
            floatingTitle.setTextColor(Color.WHITE);
        }
    }

    private Button controlButton(String label, int bg, int fg) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(fg);
        b.setTextSize(12);
        b.setTypeface(null, android.graphics.Typeface.BOLD);
        b.setAllCaps(false);
        b.setPadding(dp(8), 0, dp(8), 0);
        b.setMinHeight(dp(38));
        b.setBackground(background(bg, 12));
        return b;
    }

    private GradientDrawable background(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private int dp(float value) {
        return (int)(value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void togglePause() {
        if (!recording || recorder == null) return;
        try {
            if (!paused) {
                recorder.pause();
                paused = true;
                updateNotification("Đã tạm dừng quay");
            } else {
                recorder.resume();
                paused = false;
                updateNotification("Đang quay • MP4 • Không âm thanh");
            }
        } catch (Exception ignored) {}
    }

    private void stopRecording() {
        if (stopping) return;
        stopping = true;

        // Publish the MP4 only when MediaRecorder.stop() completes successfully.
        // A failed/too-short recording must not leave a broken video in the gallery.
        boolean completed = false;
        if (recordingStarted && recorder != null) {
            try {
                recorder.stop();
                completed = true;
            } catch (RuntimeException ignored) {
                completed = false;
            }
        }
        recording = false;
        recordingStarted = false;
        paused = false;

        try {
            if (floatingBar != null && windowManager != null) {
                windowManager.removeView(floatingBar);
            }
        } catch (Exception ignored) {}
        floatingBar = null;
        floatingHeader = null;
        floatingControls = null;
        floatingTitle = null;
        collapseButton = null;
        floatingParams = null;

        unregisterDisplayResizeListener();
        try { if (virtualDisplay != null) virtualDisplay.release(); } catch (Exception ignored) {}
        virtualDisplay = null;
        try { if (recorder != null) recorder.reset(); } catch (Exception ignored) {}
        try { if (recorder != null) recorder.release(); } catch (Exception ignored) {}
        recorder = null;
        try { if (projection != null) projection.stop(); } catch (Exception ignored) {}
        projection = null;
        try { if (output != null) output.close(); } catch (Exception ignored) {}
        output = null;

        if (videoUri != null) {
            try {
                if (completed) {
                    if (Build.VERSION.SDK_INT >= 29) {
                        ContentValues done = new ContentValues();
                        done.put(MediaStore.Video.Media.IS_PENDING, 0);
                        getContentResolver().update(videoUri, done, null, null);
                    }
                } else {
                    getContentResolver().delete(videoUri, null, null);
                }
            } catch (Exception ignored) {}
            videoUri = null;
        }

        stopForeground(true);
        stopSelf();
    }

    private Notification buildNotification(String message) {
        Intent stop = new Intent(this, RecorderService.class).setAction("STOP");
        PendingIntent stopPending = PendingIntent.getService(this, 1, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CHANNEL)
                .setContentTitle("Bones Recorder")
                .setContentText(message)
                .setSmallIcon(android.R.drawable.presence_video_online)
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(null, "Dừng quay", stopPending).build())
                .build();
    }

    private void updateNotification(String message) {
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE))
                .notify(NOTIFICATION_ID, buildNotification(message));
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL, "Bones Recorder", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE))
                    .createNotificationChannel(channel);
        }
    }

    @Override public void onDestroy() {
        if (!stopping) stopRecording();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
