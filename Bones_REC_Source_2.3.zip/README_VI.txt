BONES RECORDER 1.1 - DU AN ANDROID
Tinh nang: quay man hinh MP4, khong ghi am, toi da 1080p (khong upscale), 30 FPS, nut noi keo tha/thu gon, luu Movies/BoneRecorder.
Khong quang cao, khong tai khoan, khong quyen Internet.

Thay doi 1.1:
- Thiet ke lai giao dien chinh, sua loi cat chu va nut bat dau.
- Cua so noi co the keo tha bang cach giu phan tieu de.
- Nut - thu gon thanh vien dieu khien nho; nut + mo rong lai.
- Nut tam dung/tiep tuc va dung quay duoc lam ro hon.

Luu y:
- Android se hien hop thoai xac nhan quay man hinh moi lan.
- Can cap quyen hien thi tren ung dung khac de hien nut noi.
- Video luu trong Movies/BoneRecorder.
- Khong the ghi noi dung ma ung dung khac chu dong chan quay.
- Can kiem thu tren thiet bi that; do phan giai va toc do phu thuoc man hinh, phan cung va he thong.


BONES RECORDER 1.2
- Cửa sổ nổi có chiều rộng cố định ở cả chế độ thu gọn và mở rộng.
- Kéo thanh REC không làm thay đổi kích thước cửa sổ.
- Vị trí kéo được giới hạn trong vùng màn hình.
- Gỡ phần mô tả, thẻ thiết lập và đoạn hướng dẫn khỏi giao diện chính.


BONES RECORDER 1.3
- Khi thu gọn cửa sổ nổi, nhãn “● REC” chuyển sang màu đỏ để dễ nhận biết đang quay.
- Khi mở rộng cửa sổ, tiêu đề trở lại màu trắng.
- Khi tạm dừng, nhãn “Ⅱ PAUSE” vẫn màu trắng ở cả hai trạng thái.


Phiên bản 1.4:
- Tên ứng dụng: Bones REC.
- Giao diện hiển thị BONES RECORDER.
- Đã bỏ dòng SẴN SÀNG QUAY.
- Bổ sung ghi chú không có tính năng ghi âm.
- Nút nổi thu gọn hiển thị đầy đủ REC.
- Logo mới đồng bộ màu giao diện.

Phiên bản 1.9:
- Cân bằng lại khoảng cách phía trên nút bắt đầu quay.
- Thay logo ứng dụng bằng đúng thiết kế BONES do người dùng cung cấp (nền xanh, chữ trắng, chấm đỏ trong chữ O).

PHIEN BAN 1.9
- Cua so noi thu gon tu dong co kich thuoc theo noi dung, khong con khoang cach rong giua REC va nut mo rong.
- Nut mo rong (+) trong trang thai thu gon la hinh tron 30dp.
- Logo BONES duoc can lai theo truc doc; chu O co cham do o giua va font Lato Bold mem mai hon.


Cập nhật 1.9:
- Bỏ bộ ảnh logo launcher tùy chỉnh và tham chiếu icon trong manifest.
- Căn cạnh phải nút thu gọn thẳng hàng với cạnh phải nút DỪNG.
- Giảm một lần requestLayout dư thừa khi đổi trạng thái cửa sổ nổi.
- Giữ MediaRecorder H.264, 1080p tối đa, 30 FPS; không thêm thư viện hoặc tác vụ nền mới.


PHIEN BAN 2.0 - CHON HUONG QUAY
- Man hinh chinh co hai lua chon: QUAY DOC (1080x1920) va QUAY NGANG (1920x1080).
- Mac dinh la quay doc.
- Hay xoay dien thoai dung huong da chon truoc khi cap quyen quay.
- Huong va ty le video duoc co dinh cho ca file MP4 trong lan quay do.
- 30 FPS, H.264, MP4, khong ghi am.


PHIEN BAN 2.2 - TOI UU VA AN TOAN TAI NGUYEN
- Loai bo OrientationAwareRecorder.java khong duoc RecorderService su dung; giu mot luong ghi hinh MediaRecorder de giam ma nguon thua va do phuc tap.
- Chi cong bo video vao thu vien khi MediaRecorder.stop() thanh cong.
- Xoa video dang cho neu qua trinh ghi hinh that bai, tranh de lai MP4 hong/rong.
- Don dep cua so noi, VirtualDisplay, MediaRecorder, MediaProjection va file descriptor theo mot trinh tu thong nhat.
- Xu ly truong hop dich vu duoc khoi dong voi Intent rong.
- Dong bo versionCode 11 va versionName 2.2.

Ghi chu kiem thu: ma nguon duoc ra soat tinh logic va cau truc; can build tren GitHub Actions va kiem thu tren dien thoai that de xac nhan tuong thich codec, xoay man hinh, FPS, RAM va nhiet do.


PHIEN BAN 2.3 - THEO DOI XOAY MAN HINH
- RecorderService dang ky DisplayManager.DisplayListener trong luc quay.
- Khi man hinh vat ly doi kich thuoc/huong, VirtualDisplay duoc resize theo kich thuoc thuc cua man hinh.
- Khung MP4 van giu huong va kich thuoc ma nguoi dung da chon truoc khi quay; Android scale noi dung man hinh vao khung ma hoa co dinh.
- Huy dang ky DisplayListener truoc khi giai phong VirtualDisplay khi dung quay.
- Doc kich thuoc man hinh bang Display.getRealMetrics de tranh lay nham kich thuoc cua so ung dung.
- Dong bo versionCode 12 va versionName 2.3.

Gioi han can kiem thu tren thiet bi that:
- MediaRecorder khong doi duoc kich thuoc khung ma hoa sau khi da start. Vi vay khi xoay may, VirtualDisplay duoc resize nhung khung MP4 van giu ty le da chon; cach Android scale/crop noi dung co the khac nhau theo thiet bi va codec.
- Can thu ca quay doc -> ngang va ngang -> doc, kiem tra video co bi meo, vien den, crop hoac thu nho khong. Neu can xoay khung MP4 dong theo huong moi ma khong dung vien den/crop, can pipeline MediaCodec + OpenGL; pipeline nay nang va phuc tap hon, khong nen them neu kiem thu hien tai da dat.
