BONES RECORDER 1.1 - DU AN ANDROID
Tinh nang: quay man hinh MP4, khong ghi am, toi da 1080p (khong upscale), 30 FPS, nut noi keo tha/thu gon, luu Movies/BoneRecorder.
Khong quang cao, khong tai khoan, khong quyen Internet.

Thay doi 1.1:
- Thiet ke lai giao dien chinh, sua loi cat chu va nut bat dau.
- Cua so noi co the keo tha bang cach giu phan tieu de.
- Nut - thu gon thanh vien dieu khien nho; nut + mo rong lai.
- Nut tam dung/tiep tuc va dung quay duoc lam ro hon.

Luu y:
- Android se hien hop thoai xac nhan quay man hinh moi lan.
- Can cap quyen hien thi tren ung dung khac de hien nut noi.
- Video luu trong Movies/BoneRecorder.
- Khong the ghi noi dung ma ung dung khac chu dong chan quay.
- Can kiem thu tren thiet bi that; do phan giai va toc do phu thuoc man hinh, phan cung va he thong.


BONES RECORDER 1.2
- Cửa sổ nổi có chiều rộng cố định ở cả chế độ thu gọn và mở rộng.
- Kéo thanh REC không làm thay đổi kích thước cửa sổ.
- Vị trí kéo được giới hạn trong vùng màn hình.
- Gỡ phần mô tả, thẻ thiết lập và đoạn hướng dẫn khỏi giao diện chính.


BONES RECORDER 1.3
- Khi thu gọn cửa sổ nổi, nhãn “● REC” chuyển sang màu đỏ để dễ nhận biết đang quay.
- Khi mở rộng cửa sổ, tiêu đề trở lại màu trắng.
- Khi tạm dừng, nhãn “Ⅱ PAUSE” vẫn màu trắng ở cả hai trạng thái.


Phiên bản 1.4:
- Tên ứng dụng: Bones REC.
- Giao diện hiển thị BONES RECORDER.
- Đã bỏ dòng SẴN SÀNG QUAY.
- Bổ sung ghi chú không có tính năng ghi âm.
- Nút nổi thu gọn hiển thị đầy đủ REC.
- Logo mới đồng bộ màu giao diện.

Phiên bản 1.9:
- Cân bằng lại khoảng cách phía trên nút bắt đầu quay.
- Thay logo ứng dụng bằng đúng thiết kế BONES do người dùng cung cấp (nền xanh, chữ trắng, chấm đỏ trong chữ O).

PHIEN BAN 1.9
- Cua so noi thu gon tu dong co kich thuoc theo noi dung, khong con khoang cach rong giua REC va nut mo rong.
- Nut mo rong (+) trong trang thai thu gon la hinh tron 30dp.
- Logo BONES duoc can lai theo truc doc; chu O co cham do o giua va font Lato Bold mem mai hon.


Cập nhật 1.9:
- Bỏ bộ ảnh logo launcher tùy chỉnh và tham chiếu icon trong manifest.
- Căn cạnh phải nút thu gọn thẳng hàng với cạnh phải nút DỪNG.
- Giảm một lần requestLayout dư thừa khi đổi trạng thái cửa sổ nổi.
- Giữ MediaRecorder H.264, 1080p tối đa, 30 FPS; không thêm thư viện hoặc tác vụ nền mới.


PHIEN BAN 2.0 - QUAY MAN HINH XOAY DOC/NGANG
- Chuyen sang MediaCodec + EGL/OpenGL + MediaMuxer, khong dung MediaRecorder co kich thuoc co dinh theo man hinh luc bat dau.
- Video MP4 co khung hinh co dinh 1920x1080 (16:9) de giu mot track MP4 lien tuc.
- Khi man hinh o che do ngang, noi dung game duoc hien thi tran khung 16:9. Khi man hinh o che do doc, noi dung duoc can giua va giu dung ti le, co hai dai den hai ben. Khi xoay sang ngang, noi dung se mo rong vao khung hinh ma khong tao file moi.
- VirtualDisplay va SurfaceTexture duoc resize khi phat hien thay doi huong man hinh. Encoder khong bi khoi dong lai.
- Khong thu am. Ma hoa H.264, 1080p, muc tieu 30 FPS.
- Luu y: can build va thu nghiem tren thiet bi Android thuc te; hieu nang phu thuoc bo ma hoa phan cung va thiet bi.


PHIEN BAN 2.1 - SUA LOI KHOI TAO QUAY
- Dang ky MediaProjection.Callback truoc khi tao VirtualDisplay.
- Sua loi thu tu khoi tao co the khien Android 14 tro len tu choi bat dau quay.
- Giu nguyen bo quay MediaCodec + EGL/OpenGL + MediaMuxer, MP4 1920x1080.
- Tang versionCode len 11, versionName 2.1.
- Can build va kiem thu tren thiet bi Android thuc te.
