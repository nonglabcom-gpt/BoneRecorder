package vn.bones.recorder;

import android.content.Context;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.media.projection.MediaProjection;
import android.graphics.SurfaceTexture;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.DisplayMetrics;
import android.view.Surface;
import android.view.WindowManager;
import android.view.Display;

import android.opengl.EGL14;
import android.opengl.EGLExt;
import android.opengl.GLES11Ext;
import android.opengl.GLES20;
import android.opengl.Matrix;

import java.io.FileDescriptor;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * Captures the current display into a fixed 1920x1080 MP4 canvas.
 * Portrait content is aspect-fitted with side bars; landscape content fills the canvas.
 * The virtual display is resized when the physical display rotates, without restarting
 * the encoder or splitting the MP4 file.
 */
final class OrientationAwareRecorder implements SurfaceTexture.OnFrameAvailableListener,
        DisplayManager.DisplayListener {
    private static final int OUT_W = 1920;
    private static final int OUT_H = 1080;
    private static final long FRAME_INTERVAL_NS = 1_000_000_000L / 30L;
    private static final int EGL_RECORDABLE_ANDROID = 0x3142;

    private final Context context;
    private final MediaProjection projection;
    private final FileDescriptor outputFd;
    private final HandlerThread thread;
    private Handler handler;
    private MediaCodec encoder;
    private MediaMuxer muxer;
    private Surface encoderSurface;
    private SurfaceTexture inputTexture;
    private Surface inputSurface;
    private VirtualDisplay virtualDisplay;
    private DisplayManager displayManager;
    private WindowManager windowManager;
    private boolean muxerStarted;
    private boolean paused;
    private boolean stopping;
    private int trackIndex = -1;
    private int sourceWidth = 1080;
    private int sourceHeight = 1920;
    private int densityDpi;
    private long lastFrameNs;
    private int textureId;

    private android.opengl.EGLDisplay eglDisplay = EGL14.EGL_NO_DISPLAY;
    private android.opengl.EGLContext eglContext = EGL14.EGL_NO_CONTEXT;
    private android.opengl.EGLSurface eglSurface = EGL14.EGL_NO_SURFACE;
    private int program;
    private int positionLoc, texCoordLoc, matrixLoc, samplerLoc;
    private FloatBuffer vertices;
    private FloatBuffer texCoords;
    private final float[] textureMatrix = new float[16];
    private final float[] identity = new float[16];

    private static final float[] VERTICES = {
            -1f, -1f,  1f, -1f,  -1f, 1f,  1f, 1f
    };
    private static final float[] TEX_COORDS = {
            0f, 1f,  1f, 1f,  0f, 0f,  1f, 0f
    };

    OrientationAwareRecorder(Context context, MediaProjection projection, FileDescriptor outputFd) {
        this.context = context.getApplicationContext();
        this.projection = projection;
        this.outputFd = outputFd;
        thread = new HandlerThread("BonesREC-GL");
    }

    void start() throws Exception {
        MediaFormat format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, OUT_W, OUT_H);
        format.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
        format.setInteger(MediaFormat.KEY_BIT_RATE, 6_000_000);
        format.setInteger(MediaFormat.KEY_FRAME_RATE, 30);
        format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2);
        encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
        encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
        encoderSurface = encoder.createInputSurface();
        encoder.start();
        muxer = new MediaMuxer(outputFd, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);

        DisplayMetrics metrics = readDisplayMetrics();
        sourceWidth = Math.max(2, metrics.widthPixels);
        sourceHeight = Math.max(2, metrics.heightPixels);
        densityDpi = metrics.densityDpi;

        thread.start();
        CountDownLatch ready = new CountDownLatch(1);
        final Exception[] failure = new Exception[1];
        handler = new Handler(thread.getLooper());
        handler.post(() -> {
            try { initializeGlAndDisplay(); }
            catch (Exception e) { failure[0] = e; }
            finally { ready.countDown(); }
        });
        if (!ready.await(10, TimeUnit.SECONDS)) throw new IllegalStateException("Khởi tạo bộ quay bị quá thời gian");
        if (failure[0] != null) throw failure[0];
    }

    private DisplayMetrics readDisplayMetrics() {
        DisplayMetrics metrics = new DisplayMetrics();
        windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        Display display = windowManager.getDefaultDisplay();
        display.getRealMetrics(metrics);
        return metrics;
    }

    private void initializeGlAndDisplay() throws Exception {
        eglDisplay = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY);
        int[] versions = new int[2];
        if (eglDisplay == EGL14.EGL_NO_DISPLAY || !EGL14.eglInitialize(eglDisplay, versions, 0, versions, 1))
            throw new IllegalStateException("Không khởi tạo được EGL");

        int[] configAttrs = {
                EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8,
                EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
                EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
                EGL_RECORDABLE_ANDROID, 1, EGL14.EGL_NONE
        };
        android.opengl.EGLConfig[] configs = new android.opengl.EGLConfig[1];
        int[] count = new int[1];
        if (!EGL14.eglChooseConfig(eglDisplay, configAttrs, 0, configs, 0, 1, count, 0) || count[0] == 0)
            throw new IllegalStateException("Không tìm được EGL config");
        int[] contextAttrs = { EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE };
        eglContext = EGL14.eglCreateContext(eglDisplay, configs[0], EGL14.EGL_NO_CONTEXT, contextAttrs, 0);
        int[] surfaceAttrs = { EGL14.EGL_NONE };
        eglSurface = EGL14.eglCreateWindowSurface(eglDisplay, configs[0], encoderSurface, surfaceAttrs, 0);
        if (eglContext == EGL14.EGL_NO_CONTEXT || eglSurface == EGL14.EGL_NO_SURFACE ||
                !EGL14.eglMakeCurrent(eglDisplay, eglSurface, eglSurface, eglContext))
            throw new IllegalStateException("Không tạo được EGL encoder surface");

        program = createProgram(VERTEX_SHADER, FRAGMENT_SHADER);
        positionLoc = GLES20.glGetAttribLocation(program, "aPosition");
        texCoordLoc = GLES20.glGetAttribLocation(program, "aTexCoord");
        matrixLoc = GLES20.glGetUniformLocation(program, "uTexMatrix");
        samplerLoc = GLES20.glGetUniformLocation(program, "sTexture");
        vertices = floatBuffer(VERTICES);
        texCoords = floatBuffer(TEX_COORDS);
        Matrix.setIdentityM(identity, 0);

        int[] textures = new int[1];
        GLES20.glGenTextures(1, textures, 0);
        textureId = textures[0];
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, textureId);
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE);
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);

        inputTexture = new SurfaceTexture(textureId);
        inputTexture.setDefaultBufferSize(sourceWidth, sourceHeight);
        inputTexture.setOnFrameAvailableListener(this, handler);
        inputSurface = new Surface(inputTexture);
        virtualDisplay = projection.createVirtualDisplay("BonesREC-Capture", sourceWidth, sourceHeight,
                densityDpi, android.hardware.display.DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                inputSurface, null, handler);
        displayManager = (DisplayManager) context.getSystemService(Context.DISPLAY_SERVICE);
        displayManager.registerDisplayListener(this, handler);
    }

    @Override public void onFrameAvailable(SurfaceTexture surfaceTexture) {
        if (stopping) return;
        try {
            inputTexture.updateTexImage();
            long timestamp = inputTexture.getTimestamp();
            if (timestamp <= 0) timestamp = System.nanoTime();
            if (paused || (lastFrameNs != 0 && timestamp - lastFrameNs < FRAME_INTERVAL_NS)) {
                drainEncoder(false);
                return;
            }
            lastFrameNs = timestamp;
            inputTexture.getTransformMatrix(textureMatrix);
            renderFrame(timestamp);
            drainEncoder(false);
        } catch (Exception ignored) { }
    }

    private void renderFrame(long timestampNs) {
        EGL14.eglMakeCurrent(eglDisplay, eglSurface, eglSurface, eglContext);
        GLES20.glClearColor(0f, 0f, 0f, 1f);
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);

        float inputAspect = (float) sourceWidth / (float) sourceHeight;
        float outputAspect = (float) OUT_W / (float) OUT_H;
        int viewW = OUT_W, viewH = OUT_H;
        if (inputAspect > outputAspect) viewH = Math.max(1, Math.round(OUT_W / inputAspect));
        else viewW = Math.max(1, Math.round(OUT_H * inputAspect));
        GLES20.glViewport((OUT_W - viewW) / 2, (OUT_H - viewH) / 2, viewW, viewH);

        GLES20.glUseProgram(program);
        vertices.position(0);
        GLES20.glEnableVertexAttribArray(positionLoc);
        GLES20.glVertexAttribPointer(positionLoc, 2, GLES20.GL_FLOAT, false, 0, vertices);
        texCoords.position(0);
        GLES20.glEnableVertexAttribArray(texCoordLoc);
        GLES20.glVertexAttribPointer(texCoordLoc, 2, GLES20.GL_FLOAT, false, 0, texCoords);
        GLES20.glUniformMatrix4fv(matrixLoc, 1, false, textureMatrix, 0);
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, textureId);
        GLES20.glUniform1i(samplerLoc, 0);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4);
        GLES20.glDisableVertexAttribArray(positionLoc);
        GLES20.glDisableVertexAttribArray(texCoordLoc);
        EGLExt.eglPresentationTimeANDROID(eglDisplay, eglSurface, timestampNs);
        EGL14.eglSwapBuffers(eglDisplay, eglSurface);
    }

    void pause() { if (handler != null) handler.post(() -> paused = true); }
    void resume() { if (handler != null) handler.post(() -> { paused = false; lastFrameNs = 0; }); }

    void resizeCapturedContent(int width, int height) {
        if (handler == null || width < 2 || height < 2) return;
        handler.post(() -> resizeTo(width, height, densityDpi));
    }

    private void resizeForCurrentOrientation() {
        if (stopping || virtualDisplay == null) return;
        DisplayMetrics m = readDisplayMetrics();
        int w = Math.max(2, m.widthPixels);
        int h = Math.max(2, m.heightPixels);
        resizeTo(w, h, m.densityDpi);
    }

    private void resizeTo(int width, int height, int dpi) {
        if (stopping || virtualDisplay == null || inputTexture == null) return;
        if (width == sourceWidth && height == sourceHeight && dpi == densityDpi) return;
        sourceWidth = width;
        sourceHeight = height;
        densityDpi = dpi;
        try {
            inputTexture.setDefaultBufferSize(sourceWidth, sourceHeight);
            virtualDisplay.resize(sourceWidth, sourceHeight, densityDpi);
        } catch (Exception ignored) { }
    }

    @Override public void onDisplayAdded(int displayId) { }
    @Override public void onDisplayRemoved(int displayId) { }
    @Override public void onDisplayChanged(int displayId) {
        if (displayId == Display.DEFAULT_DISPLAY) resizeForCurrentOrientation();
    }

    void stop() {
        if (stopping) return;
        stopping = true;
        if (displayManager != null) {
            try { displayManager.unregisterDisplayListener(this); } catch (Exception ignored) { }
        }
        if (handler == null) { releaseCodecOnly(); return; }
        CountDownLatch done = new CountDownLatch(1);
        handler.post(() -> {
            try {
                if (virtualDisplay != null) virtualDisplay.release();
                virtualDisplay = null;
                if (inputSurface != null) inputSurface.release();
                inputSurface = null;
                if (inputTexture != null) inputTexture.release();
                inputTexture = null;
                if (encoder != null) {
                    try { encoder.signalEndOfInputStream(); } catch (Exception ignored) { }
                    drainEncoder(true);
                }
                releaseGl();
                releaseCodecOnly();
            } finally { done.countDown(); }
        });
        try { done.await(8, TimeUnit.SECONDS); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        try { thread.quitSafely(); } catch (Exception ignored) { }
    }

    private void drainEncoder(boolean endOfStream) {
        if (encoder == null) return;
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        long timeoutUs = endOfStream ? 10_000 : 0;
        int idle = 0;
        while (true) {
            int index;
            try { index = encoder.dequeueOutputBuffer(info, timeoutUs); }
            catch (Exception e) { break; }
            if (index == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (!endOfStream || ++idle > 50) break;
                continue;
            }
            if (index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                if (muxerStarted) throw new IllegalStateException("Encoder format changed twice");
                trackIndex = muxer.addTrack(encoder.getOutputFormat());
                muxer.start();
                muxerStarted = true;
                continue;
            }
            if (index < 0) continue;
            ByteBuffer encoded = encoder.getOutputBuffer(index);
            if (encoded != null && info.size > 0 && muxerStarted &&
                    (info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                encoded.position(info.offset);
                encoded.limit(info.offset + info.size);
                try { muxer.writeSampleData(trackIndex, encoded, info); } catch (Exception ignored) { }
            }
            boolean eos = (info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0;
            encoder.releaseOutputBuffer(index, false);
            if (eos) break;
        }
    }

    private void releaseGl() {
        try { if (eglDisplay != EGL14.EGL_NO_DISPLAY) EGL14.eglMakeCurrent(eglDisplay, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT); } catch (Exception ignored) { }
        try { if (eglSurface != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(eglDisplay, eglSurface); } catch (Exception ignored) { }
        try { if (eglContext != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(eglDisplay, eglContext); } catch (Exception ignored) { }
        try { if (eglDisplay != EGL14.EGL_NO_DISPLAY) EGL14.eglTerminate(eglDisplay); } catch (Exception ignored) { }
        eglDisplay = EGL14.EGL_NO_DISPLAY; eglContext = EGL14.EGL_NO_CONTEXT; eglSurface = EGL14.EGL_NO_SURFACE;
    }

    private void releaseCodecOnly() {
        try { if (encoder != null) encoder.stop(); } catch (Exception ignored) { }
        try { if (encoder != null) encoder.release(); } catch (Exception ignored) { }
        encoder = null;
        try { if (muxer != null && muxerStarted) muxer.stop(); } catch (Exception ignored) { }
        try { if (muxer != null) muxer.release(); } catch (Exception ignored) { }
        muxer = null;
        try { if (encoderSurface != null) encoderSurface.release(); } catch (Exception ignored) { }
        encoderSurface = null;
    }

    private static FloatBuffer floatBuffer(float[] values) {
        FloatBuffer buffer = ByteBuffer.allocateDirect(values.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
        buffer.put(values).position(0);
        return buffer;
    }

    private static int createProgram(String vertex, String fragment) {
        int vs = compileShader(GLES20.GL_VERTEX_SHADER, vertex);
        int fs = compileShader(GLES20.GL_FRAGMENT_SHADER, fragment);
        int p = GLES20.glCreateProgram();
        GLES20.glAttachShader(p, vs); GLES20.glAttachShader(p, fs); GLES20.glLinkProgram(p);
        int[] status = new int[1]; GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, status, 0);
        GLES20.glDeleteShader(vs); GLES20.glDeleteShader(fs);
        if (status[0] == 0) throw new IllegalStateException("Không liên kết được GL program: " + GLES20.glGetProgramInfoLog(p));
        return p;
    }

    private static int compileShader(int type, String source) {
        int shader = GLES20.glCreateShader(type);
        GLES20.glShaderSource(shader, source); GLES20.glCompileShader(shader);
        int[] status = new int[1]; GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, status, 0);
        if (status[0] == 0) throw new IllegalStateException("GL shader lỗi: " + GLES20.glGetShaderInfoLog(shader));
        return shader;
    }

    private static final String VERTEX_SHADER =
            "attribute vec4 aPosition;\n" +
            "attribute vec2 aTexCoord;\n" +
            "uniform mat4 uTexMatrix;\n" +
            "varying vec2 vTexCoord;\n" +
            "void main(){ gl_Position=aPosition; vTexCoord=(uTexMatrix*vec4(aTexCoord,0.0,1.0)).xy; }";
    private static final String FRAGMENT_SHADER =
            "#extension GL_OES_EGL_image_external : require\n" +
            "precision mediump float;\n" +
            "uniform samplerExternalOES sTexture;\n" +
            "varying vec2 vTexCoord;\n" +
            "void main(){ gl_FragColor=texture2D(sTexture,vTexCoord); }";
}
