package vn.bones.recorder;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQUEST_OVERLAY = 10;
    private static final int REQUEST_CAPTURE = 11;
    private MediaProjectionManager projectionManager;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        projectionManager = (MediaProjectionManager)getSystemService(Context.MEDIA_PROJECTION_SERVICE);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setGravity(Gravity.CENTER_HORIZONTAL);
        page.setPadding(28, 44, 28, 28);
        page.setBackgroundColor(0xFF111820);

        TextView title = new TextView(this);
        title.setText("BONE RECORDER");
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(24);
        title.setGravity(Gravity.CENTER);
        page.addView(title, new LinearLayout.LayoutParams(-1, 76));

        TextView details = new TextView(this);
        details.setText("QUAY MÀN HÌNH\n\nMP4  •  Tối đa 1080p  •  30 FPS\nKhông ghi âm  •  Có nút nổi");
        details.setTextColor(0xFFD5DEE7);
        details.setTextSize(16);
        details.setGravity(Gravity.CENTER);
        page.addView(details, new LinearLayout.LayoutParams(-1, 180));

        Button start = new Button(this);
        start.setText("●  BẮT ĐẦU QUAY");
        page.addView(start, new LinearLayout.LayoutParams(-1, 60));
        start.setOnClickListener(v -> checkOverlayAndStart());

        TextView hint = new TextView(this);
        hint.setText("\nAndroid sẽ hỏi quyền quay màn hình mỗi lần bắt đầu. Video nằm trong Movies/BoneRecorder.");
        hint.setTextColor(0xFF9EADB9);
        hint.setTextSize(13);
        page.addView(hint);
        setContentView(page);
    }

    private void checkOverlayAndStart() {
        if (!Settings.canDrawOverlays(this)) {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivityForResult(i, REQUEST_OVERLAY);
        } else requestCapturePermission();
    }

    private void requestCapturePermission() {
        startActivityForResult(projectionManager.createScreenCaptureIntent(), REQUEST_CAPTURE);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_OVERLAY) {
            if (Settings.canDrawOverlays(this)) requestCapturePermission();
            else Toast.makeText(this, "Cần bật quyền hiển thị nút nổi.", Toast.LENGTH_LONG).show();
        } else if (requestCode == REQUEST_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                Intent service = new Intent(this, RecorderService.class);
                service.putExtra("resultCode", resultCode);
                service.putExtra("projectionData", data);
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(service);
                else startService(service);
            } else Toast.makeText(this, "Bạn đã từ chối quyền quay màn hình.", Toast.LENGTH_SHORT).show();
        }
    }
}
