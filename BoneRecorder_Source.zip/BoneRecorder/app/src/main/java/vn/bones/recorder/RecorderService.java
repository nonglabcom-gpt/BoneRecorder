package vn.bones.recorder;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.MediaRecorder;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.*;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.WindowManager;
import android.graphics.PixelFormat;
import android.util.DisplayMetrics;
import android.widget.LinearLayout;
import android.widget.Button;
import android.widget.Toast;
import android.content.ContentValues;
import android.net.Uri;
import java.io.FileDescriptor;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class RecorderService extends Service {
    private static final String CHANNEL = "bone_recording";
    private static final int NOTIFICATION_ID = 41;
    private MediaProjection projection;
    private MediaRecorder recorder;
    private VirtualDisplay virtualDisplay;
    private android.os.ParcelFileDescriptor output;
    private Uri videoUri;
    private WindowManager windowManager;
    private LinearLayout floatingBar;
    private boolean recording = false;
    private boolean paused = false;
    private boolean stopping = false;

    @Override public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && "STOP".equals(intent.getAction())) {
            stopRecording();
            return START_NOT_STICKY;
        }
        if (intent != null && "TOGGLE".equals(intent.getAction())) {
            togglePause();
            return START_NOT_STICKY;
        }

        Notification notification = buildNotification("Đang chuẩn bị quay màn hình");
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else startForeground(NOTIFICATION_ID, notification);

        try {
            int resultCode = intent.getIntExtra("resultCode", Activity.RESULT_CANCELED);
            Intent data = intent.getParcelableExtra("projectionData");
            MediaProjectionManager manager =
                    (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
            projection = manager.getMediaProjection(resultCode, data);
            startRecording();
        } catch (Exception e) {
            Toast.makeText(this, "Không thể bắt đầu quay: " + e.getMessage(), Toast.LENGTH_LONG).show();
            stopRecording();
        }
        return START_NOT_STICKY;
    }

    private void startRecording() throws Exception {
        DisplayMetrics metrics = new DisplayMetrics();
        WindowManager wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        if (Build.VERSION.SDK_INT >= 30) {
            android.view.WindowMetrics m = wm.getCurrentWindowMetrics();
            android.graphics.Rect b = m.getBounds();
            metrics.widthPixels = b.width();
            metrics.heightPixels = b.height();
            metrics.densityDpi = getResources().getDisplayMetrics().densityDpi;
        } else {
            wm.getDefaultDisplay().getRealMetrics(metrics);
        }

        int width = metrics.widthPixels;
        int height = metrics.heightPixels;
        float scale = Math.min(1f, 1920f / Math.max(width, height));
        width = Math.max(2, ((int)(width * scale)) & ~1);
        height = Math.max(2, ((int)(height * scale)) & ~1);

        String filename = "BoneRecorder_" +
                new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".mp4";
        ContentValues values = new ContentValues();
        values.put(MediaStore.Video.Media.DISPLAY_NAME, filename);
        values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
        if (Build.VERSION.SDK_INT >= 29)
            values.put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/BoneRecorder");
        if (Build.VERSION.SDK_INT >= 29)
            values.put(MediaStore.Video.Media.IS_PENDING, 1);

        videoUri = getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
        if (videoUri == null) throw new IllegalStateException("Không tạo được tệp video");
        output = getContentResolver().openFileDescriptor(videoUri, "w");
        FileDescriptor fd = output.getFileDescriptor();

        if (Build.VERSION.SDK_INT >= 31) recorder = new MediaRecorder(this);
        else recorder = new MediaRecorder();
        recorder.setVideoSource(MediaRecorder.VideoSource.SURFACE);
        recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
        recorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
        recorder.setVideoSize(width, height);
        recorder.setVideoFrameRate(30);
        recorder.setVideoEncodingBitRate(6_000_000);
        recorder.setOutputFile(fd);
        recorder.prepare();

        projection.registerCallback(new MediaProjection.Callback() {
            @Override public void onStop() { stopRecording(); }
        }, new Handler(Looper.getMainLooper()));

        virtualDisplay = projection.createVirtualDisplay("BoneRecorder",
                width, height, metrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                recorder.getSurface(), null, null);
        recorder.start();
        recording = true;
        showFloatingControls();
        updateNotification("Đang quay • MP4 • Không âm thanh");
    }

    private void showFloatingControls() {
        windowManager = (WindowManager)getSystemService(WINDOW_SERVICE);
        floatingBar = new LinearLayout(this);
        floatingBar.setOrientation(LinearLayout.HORIZONTAL);
        floatingBar.setPadding(8, 8, 8, 8);
        floatingBar.setBackgroundColor(0xEE202D39);

        Button pause = new Button(this);
        pause.setText("TẠM DỪNG");
        pause.setOnClickListener(v -> {
            togglePause();
            pause.setText(paused ? "TIẾP TỤC" : "TẠM DỪNG");
        });
        Button stop = new Button(this);
        stop.setText("DỪNG");
        stop.setOnClickListener(v -> stopRecording());
        floatingBar.addView(pause);
        floatingBar.addView(stop);

        int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.END;
        params.x = 12; params.y = 150;
        windowManager.addView(floatingBar, params);
    }

    private void togglePause() {
        if (!recording || recorder == null) return;
        try {
            if (!paused) {
                recorder.pause();
                paused = true;
                updateNotification("Đã tạm dừng quay");
            } else {
                recorder.resume();
                paused = false;
                updateNotification("Đang quay • MP4 • Không âm thanh");
            }
        } catch (Exception ignored) {}
    }

    private void stopRecording() {
        if (stopping) return;
        stopping = true;
        try { if (recording && recorder != null) recorder.stop(); } catch (Exception ignored) {}
        recording = false;
        try { if (floatingBar != null && windowManager != null) windowManager.removeView(floatingBar); } catch (Exception ignored) {}
        floatingBar = null;
        try { if (virtualDisplay != null) virtualDisplay.release(); } catch (Exception ignored) {}
        virtualDisplay = null;
        try { if (recorder != null) recorder.reset(); } catch (Exception ignored) {}
        try { if (recorder != null) recorder.release(); } catch (Exception ignored) {}
        recorder = null;
        try { if (projection != null) projection.stop(); } catch (Exception ignored) {}
        projection = null;
        try { if (output != null) output.close(); } catch (Exception ignored) {}
        output = null;

        if (videoUri != null && Build.VERSION.SDK_INT >= 29) {
            ContentValues done = new ContentValues();
            done.put(MediaStore.Video.Media.IS_PENDING, 0);
            try { getContentResolver().update(videoUri, done, null, null); } catch (Exception ignored) {}
        }
        stopForeground(true);
        stopSelf();
    }

    private Notification buildNotification(String message) {
        Intent stop = new Intent(this, RecorderService.class).setAction("STOP");
        PendingIntent stopPending = PendingIntent.getService(this, 1, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CHANNEL)
                .setContentTitle("Bone Recorder")
                .setContentText(message)
                .setSmallIcon(android.R.drawable.presence_video_online)
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(null, "Dừng quay", stopPending).build())
                .build();
    }

    private void updateNotification(String message) {
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE))
                .notify(NOTIFICATION_ID, buildNotification(message));
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL, "Bone Recorder", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE))
                    .createNotificationChannel(channel);
        }
    }

    @Override public void onDestroy() {
        if (!stopping) stopRecording();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
