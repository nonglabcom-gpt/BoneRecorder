BONE RECORDER 1.0 - DU AN ANDROID
Tinh nang: quay man hinh MP4, khong ghi am, toi da 1080p (khong upscale), 30 FPS, nut noi tam dung/dung, luu Movies/BoneRecorder.
Khong quang cao, khong tai khoan, khong quyen Internet.

Luu y:
- Day la ma nguon, chua phai APK da bien dich hay kiem thu tren Samsung.
- Android se hien hop thoai xac nhan quay man hinh moi lan.
- Can cap quyen hien thi tren ung dung khac de hien nut noi.
- Do phan giai thuc te phu thuoc man hinh va phan cung. Video khong duoc nang cap gia tao len 1080p neu man hinh thap hon.
- Khong the ghi noi dung ma ung dung khac chu dong chan quay.
- Can test tren thiet bi that; mot so thiet bi co the co gioi han MediaProjection/MediaRecorder.

BUILD APK TRUC TUYEN BANG DIEN THOAI:
1. Giai nen BoneRecorder_Source.zip.
2. Tao repository moi tren github.com bang trinh duyet dien thoai.
3. Upload toan bo noi dung thu muc BoneRecorder vao repository (bao gom thu muc .github).
4. Mo tab Actions, chon workflow "Build Bone Recorder APK", bam Run workflow.
5. Khi job hoan tat, mo run vua chay, keo xuong Artifacts va tai BoneRecorder-debug.
6. Giai nen artifact, lay app-debug.apk va cai tren Samsung.

Workflow su dung GitHub Actions, JDK 17, Android SDK va Gradle 8.7. APK debug la ban chua ky phat hanh; chi cai tu nguon ma ban tu kiem soat.
