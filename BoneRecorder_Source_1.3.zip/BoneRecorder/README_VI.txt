BONE RECORDER 1.1 - DU AN ANDROID
Tinh nang: quay man hinh MP4, khong ghi am, toi da 1080p (khong upscale), 30 FPS, nut noi keo tha/thu gon, luu Movies/BoneRecorder.
Khong quang cao, khong tai khoan, khong quyen Internet.

Thay doi 1.1:
- Thiet ke lai giao dien chinh, sua loi cat chu va nut bat dau.
- Cua so noi co the keo tha bang cach giu phan tieu de.
- Nut - thu gon thanh vien dieu khien nho; nut + mo rong lai.
- Nut tam dung/tiep tuc va dung quay duoc lam ro hon.

Luu y:
- Android se hien hop thoai xac nhan quay man hinh moi lan.
- Can cap quyen hien thi tren ung dung khac de hien nut noi.
- Video luu trong Movies/BoneRecorder.
- Khong the ghi noi dung ma ung dung khac chu dong chan quay.
- Can kiem thu tren thiet bi that; do phan giai va toc do phu thuoc man hinh, phan cung va he thong.


BONE RECORDER 1.2
- Cửa sổ nổi có chiều rộng cố định ở cả chế độ thu gọn và mở rộng.
- Kéo thanh REC không làm thay đổi kích thước cửa sổ.
- Vị trí kéo được giới hạn trong vùng màn hình.
- Gỡ phần mô tả, thẻ thiết lập và đoạn hướng dẫn khỏi giao diện chính.


BONE RECORDER 1.3
- Khi thu gọn cửa sổ nổi, nhãn “● REC” chuyển sang màu đỏ để dễ nhận biết đang quay.
- Khi mở rộng cửa sổ, tiêu đề trở lại màu trắng.
- Khi tạm dừng, nhãn “Ⅱ PAUSE” vẫn màu trắng ở cả hai trạng thái.
